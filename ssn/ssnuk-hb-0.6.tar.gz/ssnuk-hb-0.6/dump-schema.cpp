#include "HBSBoss.h"
#include "HDBHandle.h"
#include "HFile.h"
#include "HSchema.h"
#include "HRecord.h"
#include "HiUtils.h"
#include "HiECode.h"
#include "HStream.h"

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  HSch_DB* schema;

  if (argc != 2) {
    printf ("too few arg\n");
    exit (1);
  }

  ECode		ec = ecNormal;
	
  HBSBoss*	theBoss = new HBSBoss(argv[1]);
  HDBHandle*	theHandle = new HDBHandle(theBoss);
  HSoutStream* sout = new HSoutStream();

  //ec = theHandle->Open("M.Nishibayashi", "mizuo-n");
  ec = theHandle->Open();
  if (ec == ecNormal) {

    schema = theHandle->GetDBSchema();

    schema->SchemaTo (sout);

    //	�f�[�^�x�[�X�A�N�Z�X���I������
    theHandle->Close();
  }
  delete theHandle;
  delete theBoss;

  //	free memory
  HBSBoss::FreeMemory();

  return 0;
}
