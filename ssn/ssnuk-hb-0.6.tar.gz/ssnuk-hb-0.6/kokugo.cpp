#include "HBSBoss.h"
#include "HDBHandle.h"
#include "HRecord.h"
#include "HiECode.h"

#include <stdio.h>
#include <stdlib.h>

#define DBF_KOKUGO_IDX 201
#define DBF_HONBUN 202

unsigned char key [] = {0x62, 0xB7, 0x0C, 0x81, 0x6F, 0x36, 0x4B, 0x31};

void put_honbun_char (unsigned char c)
{
  putchar (c);
  if (c == '\n')
    putchar ('h');
}

void dump_kokugo (char *conf_index, char *conf_honbun)
{
  ECode		ec = ecNormal;
  HBSBoss*	boss_index = new HBSBoss(conf_index);
  HDBHandle*	handle_index = new HDBHandle(boss_index);
  HBSBoss*	boss_honbun = new HBSBoss(conf_honbun);
  HDBHandle*	handle_honbun = new HDBHandle(boss_honbun);
  SetID sid, sid_honbun;
  RNbr rnum;
  HRecord rec, rec_honbun;
  int i, t;
  JLong n_honbun, get_honbun_size, jl_size;
  int buff_size = 256, honbun_size;
  JByte *buff = (JByte*) malloc (256);

  ec = handle_honbun->Open();
  if (ec != ecNormal)
    exit (1);

  ec = handle_index->Open();

  if (ec == ecNormal) {
    ec = handle_index->PSLocate (DBF_KOKUGO_IDX, sid);

    while (ec == ecNormal) {
      ec = handle_index->PSRead (DBF_KOKUGO_IDX, sid, rnum, &rec);
      if (ec == ecNormal) {
	JByte honbun_idx[256];

	//rec.Fetch("[1] %sn;", buff);
	//printf ("%s\n", buff);

	rec.Fetch("[2] %sn;", honbun_idx);
	//printf ("%s\n", honbun_idx);

	t = rec.ValueCount (3);
	JWord w = hitString;
	for (i=1; i<=t; i++) {
	  rec.FetchItem (3, i, w, buff, jl_size);
	  buff[jl_size] = '\0';
	  printf ("k%s\n", buff);
	}

	rec.Fetch("[4]%sn;", buff);
	printf ("m%s\n", buff);

	sprintf (buff, "[1] = %s;", honbun_idx);
	handle_honbun->SetMake (DBF_HONBUN, sid_honbun, n_honbun, buff);
	ec = handle_honbun->SetRGet (DBF_HONBUN, sid_honbun, 0, rnum, &rec_honbun);
	if (ec != ecNormal) {
	  printf ("ec: %d\n", ec);
	  exit (1);
	}
	honbun_size = rec_honbun.ValueSize (2, 1);
	if (honbun_size > buff_size) {
	  buff = (JByte*) realloc (buff, honbun_size);
	  buff_size = honbun_size;
	}
	ec = rec_honbun.FetchItem (2, 1, w, buff, get_honbun_size, handle_honbun);
	if (ec != ecNormal) {
	  printf ("ec: %d\n", ec);
	  exit (1);
	}
	handle_honbun->SetCancel (DBF_HONBUN, sid_honbun);
	putchar ('h');
	for (i=0; i<honbun_size; i++)
	  put_honbun_char (buff[i] ^ key[i % sizeof (key)]);
	putchar ('\n');
	fputs ("e\n", stdout);
      }
    }
    handle_index->PSCancel (DBF_KOKUGO_IDX, sid);

    handle_index->Close();
  }
  delete handle_index;
  delete boss_index;
  delete handle_honbun;
  delete boss_honbun;
  free (buff);

  HBSBoss::FreeMemory();
}

int main(int argc, char *argv[])
{
  if (argc < 3) {
    printf ("too few arg\n");
    exit (1);
  }

  dump_kokugo (argv[1], argv[2]);

  return 0;
}
