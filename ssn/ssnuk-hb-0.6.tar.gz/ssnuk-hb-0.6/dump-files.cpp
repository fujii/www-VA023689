#include "HBSBoss.h"
#include "HDBHandle.h"
#include "HRecord.h"
#include "HiECode.h"
#include "HStream.h"
#include "HFile.h"

#include <stdio.h>
#include <stdlib.h>

void dump_files (char *conf, int dbf_num, int file_item, int filename_item)
{
  ECode		ec = ecNormal;
  HBSBoss*	boss = new HBSBoss(conf);
  HDBHandle*	handle = new HDBHandle(boss);
  RNbr rnum;
  HRecord rec;
  SetID sid;
  char filename[256];
  JWord type;
  HDir *cd = HDir::CurrentDir ();
  HFile *file;
  HStream *stream;
  JLong size;

  ec = handle->Open();
  if (ec != ecNormal) {
    printf ("ec: %d\n", ec);
    exit (1);
  }

  if (ec == ecNormal) {
    ec = handle->PSLocate (dbf_num, sid);

    while (ec == ecNormal) {
      ec = handle->PSRead (dbf_num, sid, rnum, &rec);
      if (ec == ecNormal) {
	if (filename_item) {
	  type = hitString;
	  ec = rec.FetchItem (filename_item, 0, type, filename, size);
	  if (ec != ecNormal) {
	    printf ("ec: %d\n", ec);
	    exit (1);
	  }
	  filename[size] = '\0';
	} else {
	  sprintf (filename, "%ld", rnum);
	}
	
	file = new HFile (cd, filename);
	stream = file->OpenWriteStream ();

	type = hitFile;
	ec = rec.FetchItem (file_item, 0, type, *stream, handle);
	if (ec != ecNormal) {
	  printf ("ec: %d\n", ec);
	  exit (1);
	}

	delete file;
      }
    }
    handle->PSCancel (dbf_num, sid);
    handle->Close();
  }
  delete handle;
  delete boss;

  HBSBoss::FreeMemory();
}

int main(int argc, char *argv[])
{
  int fnin = 0;
  if (argc < 4) {
    printf ("too few arg\ndump <filename.conf> <DB file number> <file item#> [<filename item#>]");
    exit (1);
  }

  if (argc == 5) {
    fnin = atoi (argv[4]);
  }    

  dump_files (argv[1], atoi (argv[2]), atoi (argv[3]), fnin);

  return 0;
}
