#include "HBSBoss.h"
#include "HDBHandle.h"
#include "HRecord.h"
#include "HiECode.h"

#include <stdio.h>
#include <stdlib.h>

#define DBF_SN1 1
#define DBF_URL 11
#define DBF_TKANREN 21
#define DBF_TEXTDAT 101
#define DBF_INLINE 111

unsigned char key [] = {0x62, 0xB7, 0x0C, 0x81, 0x6F, 0x36, 0x4B, 0x31};

void dump_hyakka (char *conf_db01, char *conf_db02)
{
  ECode		ec = ecNormal;
  HBSBoss*	boss_db01 = new HBSBoss(conf_db01);
  HDBHandle*	handle_db01 = new HDBHandle(boss_db01);
  HBSBoss*	boss_db02 = new HBSBoss(conf_db02);
  HDBHandle*	handle_db02 = new HDBHandle(boss_db02);
  SetID sid, sid_q;
  RNbr rnum;
  HRecord rec, rec_q;
  int i;
  JLong n_q, get_size;
  int buff_size = 256, size;
  JByte *buff = (JByte*) malloc (256);
  JWord type;

  ec = handle_db02->Open();
  if (ec != ecNormal) {
    printf ("ec: %d\n", ec);
    exit (1);
  }

  ec = handle_db01->Open();
  if (ec != ecNormal) {
    printf ("ec: %d\n", ec);
    exit (1);
  }

  if (ec == ecNormal) {
    ec = handle_db01->PSLocate (DBF_SN1, sid);

    while (ec == ecNormal) {
      ec = handle_db01->PSRead (DBF_SN1, sid, rnum, &rec);
      if (ec == ecNormal) {
	JByte koumoku_id[256];
	int n_item = rec.ItemsOfRecord ();
	printf ("record#: %ld\n", rnum);
	for (i=1; i<=255 && n_item > 0; i++) {
	  int n_value = rec.ValueCount (i);
	  if (n_value > 0) {
	    n_item --;
	    for (int v=1; v<=n_value; v++) {
	      type = rec.ValueType (i, v);
	      size = rec.ValueSize (i, v) + 1;
	      if (size > buff_size) {
		buff = (JByte*) realloc (buff, size);
		buff_size = size;
	      }
	      rec.FetchItem (i, v, type, buff, get_size, handle_db01);
	      buff[get_size] = '\0';
	      switch (i) {
	      case 2:
		rec.Fetch("[2] %sn;", koumoku_id);
		break;
	      default:
		printf ("%02x: %s\n", i, buff);
		break;
	      }
	    }
	  }
	}

	// URL�μ���
	sprintf (buff, "[2] = %s;", koumoku_id);
	handle_db01->SetMake (DBF_URL, sid_q, n_q, buff);
	for (i=0; i<n_q; i++) {
	  ec = handle_db01->SetRGet (DBF_URL, sid_q, i, rnum, &rec_q);
	  if (ec != ecNormal) {
	    printf ("SetRGet ec: %d\n", ec);
	    exit (1);
	  }
	  type = hitString;
	  ec = rec_q.Fetch ("[3] %sn;", buff);
	  if (ec != ecNormal) {
	    printf ("FetchItem ec: %d\n", ec);
	    exit (1);
	  }
	  printf ("URLTEXT: %s\n", buff);
	  ec = rec_q.Fetch ("[4] %sn;", buff);
	  if (ec != ecNormal) {
	    printf ("FetchItem ec: %d\n", ec);
	    exit (1);
	  }
	  printf ("URL: %s\n", buff);
	}
	handle_db01->SetCancel (DBF_URL, sid_q);

	// ���ܤμ���
	sprintf (buff, "[1] = %s;", koumoku_id);
	handle_db02->SetMake (DBF_TEXTDAT, sid_q, n_q, buff);
	if (n_q > 0) {
	  ec = handle_db02->SetRGet (DBF_TEXTDAT, sid_q, 0, rnum, &rec_q);
	  if (ec != ecNormal) {
	    printf ("SetRGet ec: %d\n", ec);
	    exit (1);
	  }
	  size = rec_q.ValueSize (2, 1);
	  if (size > buff_size) {
	    buff = (JByte*) realloc (buff, size);
	    buff_size = size;
	  }
	  type = hitText;
	  ec = rec_q.FetchItem (2, 1, type, buff, get_size, handle_db02);
	  if (ec != ecNormal) {
	    printf ("FetchItem ec: %d\n", ec);
	    exit (1);
	  }
	  for (i=0; i<size; i++)
	    putchar (buff[i] ^ key[i % sizeof (key)]);
	  putchar ('\n');
	}
	handle_db02->SetCancel (DBF_TEXTDAT, sid_q);
      }
    }
    handle_db01->PSCancel (DBF_SN1, sid);

    handle_db01->Close();
    handle_db02->Close();
  }
  delete handle_db01;
  delete boss_db01;
  delete handle_db02;
  delete boss_db02;
  free (buff);

  HBSBoss::FreeMemory();
}

int main(int argc, char *argv[])
{
  if (argc < 3) {
    printf ("too few arg\n");
    exit (1);
  }

  dump_hyakka (argv[1], argv[2]);

  return 0;
}
