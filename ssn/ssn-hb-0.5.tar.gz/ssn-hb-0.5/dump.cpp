#include "HBSBoss.h"
#include "HDBHandle.h"
#include "HRecord.h"
#include "HiECode.h"
#include "HStream.h"

#include <stdio.h>
#include <stdlib.h>

void dump (char *conf, int dbf_num)
{
  ECode		ec = ecNormal;
  HBSBoss*	boss = new HBSBoss(conf);
  HDBHandle*	handle = new HDBHandle(boss);
  RNbr rnum;
  HRecord rec;
  int i;
  HSoutStream* sout = new HSoutStream();
  SetID sid;
  //JByte *buff = (JByte*)malloc (256);
  //int buff_size = 256;

  ec = handle->Open();
  if (ec != ecNormal) {
    printf ("ec: %d\n", ec);
    exit (1);
  }

  if (ec == ecNormal) {
    ec = handle->PSLocate (dbf_num, sid);

    while (ec == ecNormal) {
      ec = handle->PSRead (dbf_num, sid, rnum, &rec);
      if (ec == ecNormal) {
	int n_item = rec.ItemsOfRecord ();
	printf ("record: %ld, n_item: %d\n", rnum, n_item);
	for (i=1; i<=255 && n_item > 0; i++) {
	  int n_value = rec.ValueCount (i);
	  if (n_value > 0) {
	    n_item --;
	    for (int v=1; v<=n_value; v++) {
	      JWord type = rec.ValueType (i, v);
	      //JWord size = rec.ValueSize (i, v);
	      //printf ("%03d %03d %5d: ", i, v, size);
	      printf ("%03d %03d: ", i, v);
	      rec.FetchItem (i, v, type, *sout, handle);
	      sout->WriteLineTerminal ();
	    }
	  }
	}
      }
    }
    handle->PSCancel (dbf_num, sid);

    handle->Close();
  }
  //free (buff);
  delete handle;
  delete boss;
  delete sout;

  HBSBoss::FreeMemory();
}

int main(int argc, char *argv[])
{
  if (argc < 3) {
    printf ("too few arg\ndump <filename.conf> <DB file number>");
    exit (1);
  }

  dump (argv[1], atoi (argv[2]));

  return 0;
}
