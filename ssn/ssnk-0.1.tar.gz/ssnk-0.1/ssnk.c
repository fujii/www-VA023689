#include <stdio.h>
#include <stdlib.h>

#define N_HONBUN_RECORD 230283
#define N_HONBUN 230141
#define N_KOUMOKU 230141
#define BLOCK_SIZE 0x1000

struct honbun_record_t {
  unsigned int offset;		/* �쥳���ɳ��ϰ��� */
};

struct honbun_t {
  unsigned int honbun_record_id; /* ��ʸ���ϥ쥳����ID */
  int n_honbun_record;		/* ��ʸ��쥳���ɤ�ʬ�䤷�����쥳���ɿ� */
};

FILE *fp_db4vd;
FILE *fp_db4f202d;
FILE *fp_db3f201d;
struct honbun_record_t *array_honbun_record;
struct honbun_t *array_honbun;

unsigned char buff[256+1];

/* SSN_DB04/@Value.dat */

unsigned int offset = 0;

int db4vd_honbun_record (int r_offset) {
  int honbun_record_id;
  int honbun_record_length;
  int honbun_id;
  int s;
  int i, c;

  fread (buff, 1, 3, fp_db4vd);
  honbun_record_id = buff[0] << 16 | buff[1] << 8 | buff[2];
  //printf ("honbun_record no: %d\n", honbun_record_id);

  fread (buff, 1, 2, fp_db4vd);
  honbun_record_length = buff[0] << 8 | buff[1];
  //printf ("honbun_record lenght: %04x\n", honbun_record_length);

  fread (buff, 1, 2, fp_db4vd);
  if (buff[0] != 0x01 || buff[1] != 0x08) {
    fprintf (stderr, "not 01 08\n");
    exit (1);
  }

  fread (buff, 1, 1, fp_db4vd);
  s = buff[0];
  fread (buff, 1, s, fp_db4vd);
  buff[s] = '\0';
  honbun_id = atoi (buff);
  
  array_honbun_record[honbun_record_id-1].offset = offset + r_offset;
  if (array_honbun[honbun_id-1].honbun_record_id == 0
      || array_honbun[honbun_id-1].honbun_record_id > honbun_record_id)
    array_honbun[honbun_id-1].honbun_record_id = honbun_record_id;
  array_honbun[honbun_id-1].n_honbun_record ++;

  fseek (fp_db4vd, honbun_record_length-3-s, SEEK_CUR);

  return honbun_record_length + 3 + 2;
}

int db4vd_block () {
  int block_size;
  int i;

  fread (buff, 1, 2, fp_db4vd);

  if (feof (fp_db4vd))
    return 0;

  if (buff[0] == 0xf0) {
    fseek (fp_db4vd, BLOCK_SIZE-2, SEEK_CUR);
    offset += BLOCK_SIZE;
    return 1;
  }

  fread (buff, 1, 2, fp_db4vd);
  block_size = buff[0] << 8 | buff[1];
  i=0;
  while (i < block_size)
    i += db4vd_honbun_record (i+4);

  fseek (fp_db4vd, BLOCK_SIZE - block_size -4, SEEK_CUR);

  offset += BLOCK_SIZE;
  return 1;
}

void scan_db4vd ()
{
  int i;

  /* skip header */
  fseek (fp_db4vd, 0x200, SEEK_CUR);
  offset += 0x200;

  array_honbun_record = (struct honbun_record_t*) calloc (N_HONBUN_RECORD, sizeof (struct honbun_record_t));
  array_honbun = (struct honbun_t*) calloc (N_HONBUN, sizeof (struct honbun_t));

  while (db4vd_block())
    ;

  //for (i=0; i<N_HONBUN_RECORD; i++)
  //  printf ("%d %d\n", i, array_honbun_record[i].offset);
  //for (i=0; i<N_HONBUN; i++)
  //  printf ("%d %d %d\n", i, array_honbun[i].honbun_record_id, array_honbun[i].n_honbun_record);

}

/* SSN_DB04/@f202.dat  */

struct db4f202d_id_honbun_id_t {
  int db4f202d_id;
  int honbun_id;
} *db4f202d_id_honbun_id;

int db4f202d_record ()
{
  int record_id;
  int record_length;
  int s;
  int i, c;
  static index = 0;

  fread (buff, 1, 3, fp_db4f202d);
  record_id = buff[0] << 16 | buff[1] << 8 | buff[2];

  fread (buff, 1, 2, fp_db4f202d);
  record_length = buff[0] << 8 | buff[1];

  /* 1 */
  fread (buff, 1, 2, fp_db4f202d);
  if (buff[0] != 0x01 || buff[1] != 0x06) {
    fprintf (stderr, "not 01 06\n");
    exit (1);
  }
  fread (buff, 1, 1, fp_db4f202d);
  s = buff[0];
  fread (buff, 1, s, fp_db4f202d);
  buff[s] = '\0';
  db4f202d_id_honbun_id[index].db4f202d_id = atoi (buff);

  /* 2 */
  fread (buff, 1, 2, fp_db4f202d);
  if (buff[0] != 0x02 || buff[1] != 0x50) {
    fprintf (stderr, "not 02 50\n");
    exit (1);
  }
  fread (buff, 1, 1, fp_db4f202d);
  s = buff[0];
  fread (buff, 1, s, fp_db4f202d);
  db4f202d_id_honbun_id[index].honbun_id = buff[0] << 16 | buff[1] << 8 | buff[2];

  index ++;
  
  return record_length + 3 + 2;
}

int db4f202d_block ()
{
  int block_size;
  int i;

  fread (buff, 1, 2, fp_db4f202d);

  if (feof (fp_db4f202d))
    return 0;

  if (buff[0] == 0xf0) {
    fseek (fp_db4f202d, BLOCK_SIZE-2, SEEK_CUR);
    return 1;
  }

  fread (buff, 1, 2, fp_db4f202d);
  block_size = buff[0] << 8 | buff[1];
  i=0;
  while (i < block_size)
    i += db4f202d_record ();

  fseek (fp_db4f202d, BLOCK_SIZE - block_size -4, SEEK_CUR);

  return 1;
}

void scan_db4f202d ()
{
  int i;
  
  /* skip header */
  fseek (fp_db4f202d, 0x200, SEEK_CUR);

  db4f202d_id_honbun_id = calloc (sizeof (struct db4f202d_id_honbun_id_t), N_KOUMOKU);

  while (db4f202d_block ())
    ;

  /* 2ʬõ���Τ���˥����Ȥ��Ƥ����ۤ�����������  */

  /*
    for (i=0; i<N_KOUMOKU; i++)
    printf ("%d %d\n", db4f202d_id_honbun_id[i].db4f202d_id,
    db4f202d_id_honbun_id[i].honbun_id); 
  */

}


/* SSN_DB03/@f201.dat  */

void display_honbun_record_text (int record_no)
{
  int s;
  int i;
  static unsigned char key [] = {0x62, 0xB7, 0x0C, 0x81, 0x6F, 0x36, 0x4B, 0x31};

  fseek (fp_db4vd, array_honbun_record[record_no-1].offset, SEEK_SET);

  fseek (fp_db4vd, 3, SEEK_CUR);		/* honbun_record no. */
  fseek (fp_db4vd, 2, SEEK_CUR);		/* honbun_record lenght */
  /* 1 */
  fread (buff, 1, 2, fp_db4vd);
  if (buff[0] != 0x01 || buff[1] != 0x08) {
    fprintf (stderr, "not 01 08\n");
    exit (1);
  }
  fread (buff, 1, 1, fp_db4vd);
  s = buff[0];
  fseek (fp_db4vd, s, SEEK_CUR);
  /* 2 */
  fread (buff, 1, 2, fp_db4vd);
  if (buff[0] != 0x02 || buff[1] != 0x07) {
    fprintf (stderr, "not 02 07\n");
    exit (1);
  }
  fread (buff, 1, 1, fp_db4vd);
  s = buff[0];
  fseek (fp_db4vd, s, SEEK_CUR);
  /* 3 */
  fread (buff, 1, 2, fp_db4vd);
  if (buff[0] != 0x03 || buff[1] != 0x0f) {
    fprintf (stderr, "not 03 0f\n");
    exit (1);
  }
  fread (buff, 1, 2, fp_db4vd);
  s = buff[0] << 8 | buff[1];

  for (i=0; i<s ; i++)
    putchar (fgetc (fp_db4vd) ^ key[i % sizeof key]);
}

void display_honbun_text (int honbun_id)
{
  int k;

  for (k=0; k<array_honbun[honbun_id-1].n_honbun_record; k++) {
    display_honbun_record_text (array_honbun[honbun_id-1].honbun_record_id + k);
  }
  putchar ('\n');
}

int bserch_db4f202d_id_honbun_id (int db4f202d_id, int low, int high)
{
  int mid = (high + low) / 2;
  
  if (low == high){
    /* õ���Ǹ��Ĥ���ʤ��Τϡ��������� */
    printf ("fail search\n");
    exit (1);
  }

  if (db4f202d_id_honbun_id[mid].db4f202d_id == db4f202d_id)
    return db4f202d_id_honbun_id[mid].honbun_id;
  else if (db4f202d_id_honbun_id[mid].db4f202d_id > db4f202d_id)
    return bserch_db4f202d_id_honbun_id (db4f202d_id, low, mid);
  else
    return bserch_db4f202d_id_honbun_id (db4f202d_id, mid+1, high);
}


void display_honbun_text_db4f202d_if (int db4f202d_id)
{
  display_honbun_text (bserch_db4f202d_id_honbun_id (db4f202d_id, 0, N_KOUMOKU));
}


int db3f201d_record ()
{
  int record_length;
  int db4f202d_id;
  int size;
  int n_keyword;

  /* record id */
  fread (buff, 1, 3, fp_db3f201d);
  printf ("record id: %x\n", buff[0] << 16 | buff[1] << 8 | buff[2]);

  fread (buff, 1, 2, fp_db3f201d);
  record_length = buff[0] << 8 | buff[1];

  /* 1 */
  fread (buff, 1, 2, fp_db3f201d);
  if (buff[0] != 0x01 || buff[1] != 0x07) {
    fprintf (stderr, "not 01 07\n");
    exit (1);
  }
  fread (buff, 1, 1, fp_db3f201d);
  size = buff[0];
  fread (buff, 1, size, fp_db3f201d);
  //buff[size] = '\0';

  /* 2 */
  fread (buff, 1, 2, fp_db3f201d);
  if (buff[0] != 0x02 || buff[1] != 0x06) {
    fprintf (stderr, "not 02 06\n");
    exit (1);
  }
  fread (buff, 1, 1, fp_db3f201d);
  size = buff[0];
  fread (buff, 1, size, fp_db3f201d);
  buff[size] = '\0';
  db4f202d_id = atoi (buff);

  /* 3 */
  fread (buff, 1, 1, fp_db3f201d);
  if (buff[0] != 0x03) {
    fprintf (stderr, "not 03\n");
    exit (1);
  }
  fread (buff, 1, 1, fp_db3f201d);
  if (buff[0] == 0xff) {	/* ʣ��������� */
    fread (buff, 1, 3, fp_db3f201d);
    n_keyword = buff[0];
  } else {			/* ������ɤ�1�� */
    ungetc (buff[0], fp_db3f201d);
    n_keyword = 1;
  }
  for (; n_keyword > 0; n_keyword--) {
    fread (buff, 1, 1, fp_db3f201d); /* 06 */
    fread (buff, 1, 1, fp_db3f201d);
    size = buff[0];
    fread (buff, 1, size, fp_db3f201d);
    buff[size] = '\0';
    printf ("keyword: %s\n", buff);
  }

  /* 4 */
  fread (buff, 1, 2, fp_db3f201d);
  if (buff[0] != 0x04 || buff[1] != 0x06) {
    fprintf (stderr, "not 04 06\n");
    exit (1);
  }
  fread (buff, 1, 1, fp_db3f201d);
  size = buff[0];
  fread (buff, 1, size, fp_db3f201d);
  buff[size] = '\0';
  printf ("title: %s\n", buff);

  display_honbun_text_db4f202d_if (db4f202d_id);

  return record_length + 3 + 2;
}

int db3f201d_block ()
{
  int block_size;
  int i;

  fread (buff, 1, 2, fp_db3f201d);

  if (feof (fp_db3f201d))
    return 0;

  if (buff[0] == 0xf0) {
    fseek (fp_db3f201d, BLOCK_SIZE-2, SEEK_CUR);
    return 1;
  }

  fread (buff, 1, 2, fp_db3f201d);
  block_size = buff[0] << 8 | buff[1];
  i=0;
  while (i < block_size)
    i += db3f201d_record ();

  if (block_size != i) {
    printf ("error\n");
    exit (1);
  }
    
  fseek (fp_db3f201d, BLOCK_SIZE - block_size -4, SEEK_CUR);

  return 1;
}

void scan_db3f201d ()
{
  fseek (fp_db3f201d, 0x200, SEEK_CUR);

  while (db3f201d_block ())
    ;
}

int main (int argc, char *argv[])
{
  int i;

  if (argc != 4) {
    fputs ("too few argument\n", stderr);
    exit (1);
  }

  fp_db4vd = fopen (argv[1], "rb");
  if (!fp_db4vd) {
    fprintf (stderr, "can not open %s\n", argv[1]);
    exit (1);
  }
  scan_db4vd ();

  fp_db4f202d = fopen (argv[2], "rb");
  if (!fp_db4f202d) {
    fprintf (stderr, "can not open %s\n", argv[2]);
    exit (1);
  }
  scan_db4f202d ();

  fp_db3f201d = fopen (argv[3], "rb");
  if (!fp_db3f201d) {
    fprintf (stderr, "can not open %s\n", argv[3]);
    exit (1);
  }
  scan_db3f201d ();

  return 0;
}
