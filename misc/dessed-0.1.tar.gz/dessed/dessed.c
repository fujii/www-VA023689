/*
 *    dessed (C) 2001 Hironori FUJII
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <libgen.h>
#include "oct.h"

typedef struct
{
  unsigned char type;
  unsigned int start;
  unsigned int end;
  unsigned int diff;
  unsigned char data[4];
  char filename[31];
} ssedinfo;

FILE *
fopen_icase (char *dirname, char *basename, char *mode)
{
  int i;
  char *fullname;
  int len_fullname;
  FILE *rv;
  
  fullname = malloc (strlen (dirname) + 1 + strlen (basename) + 1);

  strcpy (fullname, dirname);
  strcat (fullname, "/");
  strcat (fullname, basename);

  len_fullname = strlen (fullname);

  for (i=strlen(dirname)+1; i<len_fullname; i++)
    fullname[i] = toupper (fullname[i]);

  while (1)
    {
      rv = fopen (fullname, mode);
      if (rv)
	{
	  printf ("opening %s\n", fullname);
	  free (fullname);
	  return rv;
	}

      for (i=strlen(dirname)+1; i<len_fullname; i++)
	{
	  if (isupper (fullname[i]))
	    {
	      fullname[i] = tolower (fullname[i]);
	      break;
	    }
	  else if (islower (fullname[i]))
	    {
	      if (i == len_fullname - 1)
		return 0;
	      fullname[i] = toupper (fullname[i]);
	    }
	}
    }

  return 0;
}

void
extend_sseddata (FILE *fp_dic, FILE *fp_out)
{
  int i;
  unsigned char header[64];
  unsigned char buff[4];
  unsigned int n_chunk;
  unsigned int *offset;
  char cookie[] = "SSEDDATA";


  oct_read (header, sizeof header, fp_dic);

  if (strncmp (header, cookie, strlen (cookie)))
    {
      fprintf (stderr, "This is not a SSEDDATA file.\n");
      exit (1);
    }

  n_chunk = oct_cat2 (header[22], header[23]);
  offset = calloc (n_chunk, sizeof(*offset));

  for (i=0; i<n_chunk; i++)
    {
      oct_read (buff, 4, fp_dic);
      offset[i] = oct_cat4 (buff[0], buff[1], buff[2], buff[3]);
    }

  for (i=0; i<n_chunk; i++)
    {
      int n_data;
      unsigned char win[0xff0];
      int d;
      unsigned int wintop = 0;
      unsigned int pos = 0;

      oct_seek (fp_dic, offset[i]+2, SEEK_SET);

      oct_read (buff, 3, fp_dic);

      n_data = oct_cat2 (buff[0], buff[1]);

      /* $B%9%i%$%IAk$N=i4|2=(B */
      memset (win, buff[2], sizeof win);

      for (d=0; d<n_data; d++)
	{
	  int j;
	  int wp, len, w;
	  oct_read (buff, 3, fp_dic);

	  wp = ((int)buff[0] << 4) | (buff[1] >> 4);
	  len = buff[1] & 0x0f;

	  for (j=0; j<len; j++)
	    {
	      w = wp + wintop;
	      if (w >= sizeof win)
		w -= sizeof win;
	      win[wintop] = win[w];
	      wintop ++;
	      if (wintop >= sizeof win)
		wintop = 0;
	      oct_write (&win[w], 1, fp_out);
	      pos ++;
	    }

	  /*
	   *  $B:G8e$N%G!<%?$G!"4{$K(B2048$B$NG\?t%P%$%H=PNO$7$F$$$k(B
	   */
	  if (d == n_data-1 && !(pos & 0x7ff))
	    break;

	  win[wintop] = buff[2];
	  wintop ++;
	  if (wintop >= sizeof win)
	    wintop = 0;
	  oct_write (&buff[2], 1, fp_out);
	  pos ++;

	}

    }

  return;
}

int
main (int argc, char *argv[])
{
  int i;
  int n_element;
  int n_gaiji = 0;
  unsigned char header[0x80];
  unsigned char buff[0x30];
  FILE *fp_idx;
  FILE *fp_out;
  char cookie[] = "SSEDINFO";
  ssedinfo *ss;
  char *dir_name, *p1, *p2;

  if (argc < 3)
    {
      fprintf (stderr, "%s <file.idx> HONMON\n", argv[0]);
      exit (1);
    }

  fp_idx = fopen (argv[1], "r");
  if (!fp_idx)
    {
      fprintf (stderr, "can't open: %s\n", argv[1]);
      exit (1);
    }

  oct_read (header, sizeof header, fp_idx);

  if (strncmp (header, cookie, strlen (cookie)))
    {
      fprintf (stderr, "This is not a SSEDINFO file: %s\n", argv[1]);
      exit (1);
    }

  n_element = header[0x4d];

  fp_out = fopen (argv[2], "w");
  if (!fp_out)
    {
      fprintf (stderr, "can't open: %s\n", argv[2]);
      exit (1);
    }

  ss = calloc (n_element, sizeof (ssedinfo));
  if (!ss)
    {
      fprintf (stderr, "can't calloc\n");
      exit (1);
    }

  for (i=0; i<n_element; i++)
    {
      
      oct_read (buff, 0x30, fp_idx);
      ss[i].type = buff[3];
      ss[i].start = oct_cat4 (buff[4], buff[5], buff[6], buff[7]);
      ss[i].end = oct_cat4 (buff[8], buff[9], buff[10], buff[11]);
      ss[i].data[0] = buff[12];
      ss[i].data[1] = buff[13];
      ss[i].data[2] = buff[14];
      ss[i].data[3] = buff[15];
      strcpy (ss[i].filename, &buff[17]);

      ss[i].diff = ss[i].end - ss[i].start;

      if (ss[i].start == 0)
	n_gaiji ++;

      printf ("%3d  %s\n", i, ss[i].filename);

    }

  fclose (fp_idx);

  memset (buff, 0, sizeof buff);
  buff[0] = (n_element - n_gaiji) >> 8;
  buff[1] = n_element - n_gaiji;
  
  oct_write (buff, 16, fp_out);

  for (i=0; i<n_element; i++)
    {
      if (ss[i].start == 0)
	continue;

      buff[0] = ss[i].type;
      buff[1] = 0;

      buff[2] = ss[i].start >> 24;
      buff[3] = ss[i].start >> 16;
      buff[4] = ss[i].start >> 8;
      buff[5] = ss[i].start >> 0;

      buff[6] = ss[i].diff >> 24;
      buff[7] = ss[i].diff >> 16;
      buff[8] = ss[i].diff >> 8;
      buff[9] = ss[i].diff >> 0;

      buff[10] = ss[i].data[0];
      buff[11] = ss[i].data[1];
      buff[12] = ss[i].data[2];
      buff[13] = ss[i].data[3];

      buff[14] = 0;
      buff[15] = 0;

      oct_write (buff, 16, fp_out);
    }

  memset (buff, 0, 16);
  for (i=n_element - n_gaiji + 1; i< 0x80; i++)
    oct_write (buff, 16, fp_out);


  p1 = strdup (argv[1]);
  p2 = dirname (p1);
  dir_name = strdup (p2);
  free (p1);
  
  for (i=0; i<n_element; i++)
    {
      FILE *fp_dic;

      if (ss[i].start == 0)
	continue;

      fp_dic = fopen_icase (dir_name, ss[i].filename, "r");
      if (!fp_dic)
	{
	  fprintf (stderr, "can't open: %s\n", ss[i].filename);
	  exit (1);
	}

      extend_sseddata (fp_dic, fp_out);
    }

  free (dir_name);

  return 0;
}
