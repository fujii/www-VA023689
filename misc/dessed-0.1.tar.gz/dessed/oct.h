#define oct_cat4(a, b, c, d) ((a << 24) | (b << 16) | (c << 8) | d)
#define oct_cat2(a, b) ((a << 8) | b)

#define oct_read(dest, size, fp) fread(dest, size, 1, fp)
#define oct_write(src, size, fp) fwrite(src, size, 1, fp)
#define oct_seek fseek
