use strict;
use integer;
use FreePWING::FPWUtils::FPWParser;
use Encode;

package WingHandler;
use base qw(XML::SAX::Base);
use Data::Dumper;

sub to_euc {
    my ($s) = @_;
    Encode::encode("euc-jp", $s);
}

sub to_tag {
    &to_euc;
}

sub new {
    my $self = bless {};
}

sub start_document {
    my ($self) = @_;
    $self->{state} = ['root'];
    $self->{fpwword2} = FreePWING::FPWUtils::Word2->new();
    $self->{fpwheading} = FreePWING::FPWUtils::Heading->new();
    $self->{fpwtext} = FreePWING::FPWUtils::Text->new();
    $self->{fpwmenu} = FreePWING::FPWUtils::Menu->new();
    $self->{fpwcopyright} = FreePWING::FPWUtils::Copyright->new();

    $self->{fpwword2}->open()   || die $self->{fpwword2}->error_message() . "\n";
    $self->{fpwheading}->open() || die $self->{fpwheading}->error_message() . "\n";
    $self->{fpwtext}->open()    || die $self->{fpwtext}->error_message() . "\n";
    $self->{fpwmenu}->open()    || die $self->{fpwmenu}->error_message() . "\n";
    $self->{fpwcopyright}->open()    || die $self->{fpwcopyright}->error_message() . "\n";
}

sub end_document {
    my ($self) = @_;
    $self->{fpwword2}->close()   || die $self->{fpwword2}->error_message() . "\n";
    $self->{fpwheading}->close() || die $self->{fpwheading}->error_message() . "\n";
    $self->{fpwtext}->close()    || die $self->{fpwtext}->error_message() . "\n";
    $self->{fpwmenu}->close()    || die $self->{fpwmenu}->error_message() . "\n";
    $self->{fpwcopyright}->close()    || die $self->{fpwcopyright}->error_message() . "\n";
}

sub start_element {
    my ($self, $data) = @_;
    #print Dumper($data);
    my $name = $data->{LocalName};
    my $state = $self->{state}->[0];
    my $target;

    if ($state eq 'root') {
	if ($name eq 'wingml') {
	    unshift(@{$self->{state}}, 'wingml');
	}
    } elsif ($state eq 'wingml') {
	if ($name eq 'body') {
	    unshift(@{$self->{state}}, 'body');
	} elsif ($name eq 'menu') {
	    unshift(@{$self->{state}}, 'menu');
	} elsif ($name eq 'copyright') {
	    unshift(@{$self->{state}}, 'copyright');
	}
    } elsif ($state eq 'body') {
	if ($name eq 'entry') {
	    $self->{fpwtext}->new_entry();
	} elsif ($name eq 'heading') {
	    $self->{fpwheading}->new_entry();
	    unshift(@{$self->{state}}, 'heading');
	} elsif ($name eq 'word') {
	    my $s = to_euc($data->{Attributes}->{'{}key'}->{Value});
	    $self->{fpwword2}->add_entry($s, $self->{fpwheading}->entry_position(),
					 $self->{fpwtext}->entry_position());
	} else {
	    $target = $self->{fpwtext};
	}
    } elsif ($state eq 'heading') {
	if ($name eq 'context'
	    || $name eq 'tag'
	    || $name eq 'keyword'
	    || $name eq 'ref'
	    || $name eq 'br'
	    || $name eq 'indent') {
	    # invalid content
	} else {
	    $target = $self->{fpwheading};
	}
    } elsif ($state eq 'menu') {
	$target = $self->{fpwmenu};
    } elsif ($state eq 'copyright') {
	$target = $self->{fpwcopyright};
    }
    if ($target) {
	if ($name eq 'keyword') {
	    $target->add_keyword_start();
	} elsif ($name eq 'tag') {
	    my $tag = to_tag($data->{Attributes}->{'{}tag'}->{Value});
	    $target->add_entry_tag($tag);
	} elsif ($name eq 'context') {
	    $target->new_context();
	} elsif ($name eq 'br') {
	    $target->add_newline();
	} elsif ($name eq 'indent') {
	    my $level = $data->{Attributes}->{'{}level'}->{Value};
	    $target->add_indent_level($level);
	} elsif ($name eq 'ref') {
	    my $tag = to_tag($data->{Attributes}->{'{}ref'}->{Value});
	    $self->{ref_tag} = $tag;
	    $target->add_reference_start();
	} elsif ($name eq 'sup') {
	    $target->add_superscript_start();
	} elsif ($name eq 'sub') {
	    $target->add_subscript_start();
	} elsif ($name eq 'em') {
	    $target->add_emphasis_start();
	} elsif ($name eq 'nowrap') {
	    $target->add_nowrap_start();
	} elsif ($name eq 'font') {
	    my $font = to_euc($data->{Attributes}->{'{}font'}->{Value});
	    $target->add_font_start($font);
	}
    }
};

sub end_element {
    my ($self, $data) = @_;
    my $name = $data->{LocalName};
    my $state = $self->{state}->[0];
    my $target;

    if ($state eq 'root') {
    } elsif ($state eq 'wingml') {
	if ($name eq 'wingml') {
	    shift(@{$self->{state}});
	}
    } elsif ($state eq 'body') {
	if ($name eq 'body') {
	    shift(@{$self->{state}});
	} elsif ($name eq 'entry') {
	} elsif ($name eq 'tag') {
	} elsif ($name eq 'word') {
	} else {
	    $target = $self->{fpwtext};
	}
    } elsif ($state eq 'heading') {
	if ($name eq 'heading') {
	    shift(@{$self->{state}});
	} elsif ($name eq 'context'
		 || $name eq 'tag'
		 || $name eq 'keyword'
		 || $name eq 'ref'
		 || $name eq 'br'
		 || $name eq 'indent') {
	    # invalid content
	} else {
	    $target = $self->{fpwheading};
	}
    } elsif ($state eq 'menu') {
	if ($name eq 'menu') {
	    shift(@{$self->{state}});
	} else {
	    $target = $self->{fpwmenu};
	}
    } elsif ($state eq 'copyright') {
	if ($name eq 'copyright') {
	    shift(@{$self->{state}});
	} else {
	    $target = $self->{fpwcopyright};
	}
    }
    if ($target) {
	if ($name eq 'keyword') {
	    $target->add_keyword_end();
	} elsif ($name eq 'context') {
	} elsif ($name eq 'br') {
	} elsif ($name eq 'indent') {
	} elsif ($name eq 'ref') {
	    $target->add_reference_end($self->{ref_tag});
	} elsif ($name eq 'sup') {
	    $target->add_superscript_end();
	} elsif ($name eq 'sub') {
	    $target->add_subscript_end();
	} elsif ($name eq 'em') {
	    $target->add_emphasis_end();
	} elsif ($name eq 'nowrap') {
	    $target->add_nowrap_end();
	} elsif ($name eq 'font') {
	    $target->add_font_end();
	}
    }
};

sub characters {
    my ($self, $data) = @_;
    my $state = $self->{state}->[0];
    my $target;

    if ($state eq 'body') {
	$target = $self->{fpwtext};
    } elsif ($state eq 'heading') {
	$target = $self->{fpwheading};
    } elsif ($state eq 'menu') {
	$target = $self->{fpwmenu};
    } elsif ($state eq 'copyright') {
	$target = $self->{fpwcopyright};
    }
    if ($target) {
	my $text = to_euc($data->{Data});
	$target->add_text($text);
    }
}

package main;

use XML::SAX;

my $parser = XML::SAX::ParserFactory->parser(Handler => WingHandler->new);

binmode('STDIN', ":encoding(euc-jp)");
binmode('STDOUT', ":encoding(euc-jp)");

$parser->parse_file('STDIN');

