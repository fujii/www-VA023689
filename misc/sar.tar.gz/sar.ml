open Fujii

(*
#load "fujii.cmo";;
#load "am.cmo";;
*)

type action = Action of int * int

let automaton = [|
  [Action (1, -1); Action (2, -1)];
  [Action (0, 0); Action (0, 1)];
  [Action (0, 2); Action (0, 3)];
|]

let _ = Random.self_init ()

let n_neuron_status = 100
let n_neuron_action = 100
let n_neuron_reward = 100
let n_status = 3
let n_action = 2
let n_reward = 4

let make_random_pattern n =
  Array.init n (fun _ -> if Random.bool () then 1. else -1.)

let status_patterns = Array.init n_status (fun _ -> make_random_pattern n_neuron_status)
let action_patterns = Array.init n_action (fun _ -> make_random_pattern n_neuron_action)
let reward_patterns = Array.init n_reward (fun _ -> make_random_pattern n_neuron_reward)

let msa_overlaps = Array.make n_action 0.
let msr_overlaps = Array.make n_reward 0.
let lsa_overlaps = Array.make n_action 0.
let lsr_overlaps = Array.make n_reward 0.

let calc_overlaps overlaps am patterns =
  assert ((Array.length overlaps) = (Array.length patterns));
  Array.iteri (fun i p -> overlaps.(i) <- am#overlap p) patterns

let array_max a =
  let max = ref a.(0) in
  let idx = ref 0 in
    for i=1 to Array.length a - 1 do
      if !max < a.(i)
      then (
	max := a.(i);
	idx := i
      )
    done;
    !idx

let status_action am overlaps status_idx =
  am#cue status_patterns.(status_idx);
  calc_overlaps overlaps am action_patterns;
  let idx = array_max overlaps in
    if overlaps.(idx) > 0.3 then
      Some idx
    else
      None

let status_reward am overlaps status_idx =
  am#cue status_patterns.(status_idx);
  calc_overlaps overlaps am reward_patterns;
  let idx = array_max overlaps in
    if overlaps.(idx) > 0.3 then
      Some idx
    else
      None

let random_action () =
  Random.int n_action

let exploratory_random_action action =
  let a = Random.int (n_action-1) in
    if a = action
    then n_action-1
    else a

let action status_idx am_msa am_msr am_lsa am_lsr =
  let ma = status_action am_msa msa_overlaps status_idx in
  let mr = status_reward am_msr msr_overlaps status_idx in
  let la = status_action am_lsa lsa_overlaps status_idx in
  let lr = status_reward am_lsr lsr_overlaps status_idx in
  let print_int_option str = function
      None -> print_string "--"
    | Some a ->
	print_string str;
	print_int a in
  let print_status s =
    print_string "s";
    print_int s in
  let print_action a = 
    print_int_option "a" a in
  let print_reward r =
    print_int_option "r" r in
  let determine ma mr la lr =
    match (ma, mr, la, lr) with
	(Some ma, Some mr, Some la, Some lr) ->
	  if ma = la && mr = lr then
	    if Random.int 5 = 0
	    then (exploratory_random_action ma, "exp rnd")
	    else (la, "mtm=ltm")
	  else if mr < lr
	  then (la, "ltm")
	  else (ma, "mtm")
      | (Some ma, Some mr, _, _) -> (ma, "mtm")
      | (_, _, Some la, Some lr) -> (la, "ltm")
      | (_, _, _, _) -> (random_action (), "rnd") in
    print_newline ();
    print_string "node ";print_status status_idx;print_newline ();
    print_string "msa ";print_action ma;print_string "   ";print_float_array msa_overlaps;
    print_string "msr ";print_reward mr;print_string "   ";print_float_array msr_overlaps;
    print_string "lsa ";print_action la;print_string "   ";print_float_array lsa_overlaps;
    print_string "lsr ";print_reward lr;print_string "   ";print_float_array lsr_overlaps;
    match determine ma mr la lr with
	(action, string) ->
	  print_string "action ";
	  print_action (Some action);
	  print_string " by ";
	  print_string string;
	  print_newline ();
	  action

let propagate_reward am priv next =
  am#cue status_patterns.(next);
  am#memorize status_patterns.(priv) (am#xs ())

let step am_msa am_msr am_lsa am_lsr status_idx =
  let print_reward r =
    if r <> -1 then (
      print_string "reward: r";
      print_int r;
      print_newline ()
    ) in
  let a = action status_idx am_msa am_msr am_lsa am_lsr in
    match List.nth automaton.(status_idx) a with
	 Action (next_status_idx, reward) ->
	   print_reward reward;
	   am_msa#memorize status_patterns.(status_idx) action_patterns.(a);
	   am_lsa#memorize status_patterns.(status_idx) action_patterns.(a);
	   if reward = -1 then (
	     propagate_reward am_msr status_idx next_status_idx;
	     propagate_reward am_lsr status_idx next_status_idx
	   )
	   else (
	     am_msr#memorize status_patterns.(status_idx) reward_patterns.(reward);
	     am_lsr#memorize status_patterns.(status_idx) reward_patterns.(reward)
	   );
	   next_status_idx

let am_msa = new Am.am n_neuron_status n_neuron_action 1. 0.3
let am_msr = new Am.am n_neuron_status n_neuron_reward 1. 0.3
let am_lsa = new Am.am n_neuron_status n_neuron_action 1. 0.01
let am_lsr = new Am.am n_neuron_status n_neuron_reward 1. 0.01

let run () = iterator 100 (step am_msa am_msr am_lsa am_lsr) 0

let _ = run ()
