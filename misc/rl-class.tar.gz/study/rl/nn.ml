let c = 50.
let c' = 10.
let h = 0.5
let k = -1.0
let m = 10
let a = 4
let tau = 0.01
let tau' = 0.0001
let alpha = 0.01

let mul_sum xs ys =
  let sum = ref 0. in
    for i=0 to Array.length xs - 1 do
      sum := !sum +. xs.(i) *. ys.(i)
    done;
    !sum

let f u =
  let a = ~-.c *. u in
  let a' = c' *. (abs_float u -. h) in
    (1. -. exp a) *. (1. +. k *. exp a') /. (1. +. exp a) /. (1. +. exp a')

class nn n_neuron =
object (self)
  val n = n_neuron			(* the number of neurons *)
  val mutable wss =			(* weights *)
    Array.init n_neuron (fun _ -> (Array.make n_neuron 0.))
  val mutable wss' = Array.init n_neuron (fun _ -> (Array.make n_neuron 0.))
  val mutable us = Array.make n_neuron 0. (* internal states *)
  val mutable ys = Array.make n_neuron 0. (* outputs *)
  val mutable xs = Array.make n_neuron 0. (* outputs *)
  val mutable vs = Array.make n_neuron 0. (* vector *)
  val smooth_pattern = Array.init (a+1) (fun _ -> Array.make n_neuron 0.)

  method valid_pattern pattern =
    Array.length pattern = n

  method calc_output () =
    for i=0 to n-1 do
      ys.(i) <- f us.(i);
      xs.(i) <- if us.(i) >= 0. then 1. else -1.
    done;
    for i=0 to n-1 do
      vs.(i) <- mul_sum ys wss.(i)
    done

  method set pattern =
    for i=0 to n-1 do
      us.(i) <- pattern.(i) *. h *. 0.5
    done;
    self#calc_output ()

  method step () =
    for i=0 to n-1 do
      us.(i) <- us.(i) +. (vs.(i) -. us.(i)) *. tau
    done;
    self#calc_output ()

  method overlap pattern =
    mul_sum xs pattern /. float_of_int n

  method calc_smooth_pattern from dist =
    let count_diff x y =
      let rv = ref 0 in
	for i=0 to n-1 do
	  if x.(i) <> y.(i)
	  then incr rv
	done;
	!rv in
      for i=0 to n-1 do
	smooth_pattern.(0).(i) <- from.(i)
      done;
      for i=1 to a do
	let n_diff = count_diff smooth_pattern.(i-1) dist in
	let n_turn = ref (n_diff / (a-i+1)) in
	  for j=0 to n-1 do
	    if smooth_pattern.(i-1).(j) = dist.(j) || !n_turn = 0
	    then smooth_pattern.(i).(j) <- smooth_pattern.(i-1).(j)
	    else (smooth_pattern.(i).(j) <- dist.(j);
		  decr n_turn)
	  done
      done

  method calc_wss' () =
    for i = 0 to n-1 do
      for j = 0 to n-1 do
	wss'.(i).(j) <- 0.;
	for p = 0 to a-1 do
	  wss'.(i).(j) <- wss'.(i).(j) +.
 	    smooth_pattern.(p).(j) *. smooth_pattern.(p+1).(i)
	done;
	wss'.(i).(j) <- wss'.(i).(j) /. float_of_int a /. float_of_int n *. alpha
      done 
    done 

  method calc_wss () =
    for i = 0 to n-1 do
      for j = 0 to n-1 do
	wss.(i).(j) <- wss.(i).(j) +. (-.wss.(i).(j) *. tau') +. wss'.(i).(j)
      done
    done

  method memorize from dist =
    assert (self#valid_pattern from);
    assert (self#valid_pattern dist);
    self#calc_smooth_pattern from dist;
    self#calc_wss' ();
    self#calc_wss ();
    
  method get_smooth_pattern () = smooth_pattern
  method get_wss' () = wss'
  method get_wss () = wss
  method get_us () = us
  method get_ys () = ys
  method get_xs () = xs
  method get_vs () = vs
end

(*  *)
