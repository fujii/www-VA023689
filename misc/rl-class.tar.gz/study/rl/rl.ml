open List
open Fujii
open Nn
open Field

(*
#load "fujii.cmo";;
#load "nn.cmo";;
#load "field.cmo";;
*)

let n_neuron = 100

let make_random_pattern n =
  Array.init n (fun _ -> if Random.bool () then 1. else -1.)

let node_patterns = Array.init n_node (fun _ -> make_random_pattern n_neuron)

let node_overlaps = Array.init n_node (fun _ -> 0.)

let memorize_node nn () =
  for i=0 to n_node-2 do
    nn#memorize node_patterns.(i) node_patterns.(i+1)
  done

let calc_node_overlaps nn =
  for i=0 to n_node-1 do
    node_overlaps.(i) <- nn#overlap node_patterns.(i)
  done

let array_max a =
  let max = ref a.(0) in
  let idx = ref 0 in
    for i=1 to Array.length a - 1 do
      if !max < a.(i)
      then (
	max := a.(i);
	idx := i
      )
    done;
    !idx

let recall nn start_idx time =
  let idx_list = ref [start_idx] in
  let current_idx = ref start_idx in
    nn#set node_patterns.(start_idx);
    for i=1 to time do
      nn#step ();
      calc_node_overlaps nn;
      let max_idx = array_max node_overlaps in
	if !current_idx <> max_idx
	then (
	  current_idx := max_idx;
	  idx_list := !current_idx::!idx_list
	)
    done;
    List.rev !idx_list
    
  
(*
let node_pattern_list =  map (fun _ -> make_random_pattern n_neuron) (make_list n_node)

let learn nn () =
  ignore (map_adjoining_pair (nn#memorize) (take 10 node_pattern_list))
*)
let iter_sp f sp = function
    [] -> ()
  | x::xs ->
      f x;
      List.iter (fun x -> sp (); f x) xs

let print_x_list print_x xs =
  let print_tab () = print_string " " in
  iter_sp print_x print_tab xs;
  print_newline ()

let print_float_list = print_x_list print_float
let print_int_list = print_x_list print_int

let print_float_array a =
  print_float a.(0);
  for i=1 to Array.length a - 1 do
    print_string " ";
    print_float a.(i);
  done;
  print_newline ()
  

let rec repeat f n =
  if n = 0
  then ()
  else (f ();
	repeat f (n-1))

(*
let remember_1 nn () =
  nn#step ();
  print_float_list (map (nn#overlap) (take 10 node_pattern_list))

let remember_2 nn () =
  nn#step ();
  print_float_list (map (mul_sum (nn#get_us ())) (take 10 node_pattern_list))

let remember = remember_1

let _ = let nn = new nn n_neuron in
  repeat (learn nn) 50;
  nn#set (hd node_pattern_list);
  repeat (remember nn) 1000

*)

let _ =
  let nn = new nn n_neuron in
  repeat (memorize_node nn) 100;
  print_int_list (recall nn 0 10000)


let stroll time =
  let current_idx = ref 0 in
  for i=1 to time do
    let next_idx = rand
  done

(**)
