(*
#load "fujii.cmo";;
#load "nn.cmo";;
*)
open Fujii
open List
open Nn

let length = 3
let dimension = 2
let n_node = pow_int length dimension
let n_reward = n_node / 10

type position = Position of int list

let valid_position_p (Position p) = 
  let range_p x = 0 <= x && x < length in
    (List.length p = dimension)
    && for_all range_p p

let position_of_index i =
  assert (0 <= i && i < n_node);
  let rec loop dim lst i = 
    if dim = 0
    then lst
    else loop (dim-1) (i mod length :: lst) (i / length) in
    Position (loop dimension [] i)

let index_of_position (Position pos) =
  assert (valid_position_p (Position pos));
  fold_left (fun x y -> x*length+y) 0 pos

let _ = assert (for_all (fun x -> index_of_position (position_of_index x) = x)
		  (make_list n_node))

let normalize_position (Position pos) =
  let nml x = if x = length then 0 else x in
    Position (map nml pos)

let dist_index from =
  let make_vector dim =
    map (fun x -> map (fun y -> if x = y then 1 else 0) (make_list dim)) (make_list dim) in
  let add = 
    map2 (fun x y -> if x+y=length then 0 else x+y) in
    match (position_of_index from) with
	Position pos -> map (fun dir -> index_of_position (Position (add pos dir)))
	  (make_vector dimension)

let automaton = Array.init n_node dist_index

let output_automaton () =
  let print_edge from dist =
    print_int from;
    print_string " -> ";
    print_int dist;
    print_newline () in
  print_string "digraph automaton {\n";
  iter (fun from -> iter
	  (print_edge from)
	  (dist_index from)) (make_list n_node);
  print_string "}\n"

(* let _ = output_automaton () *)

