open List
open Fujii
open Nn
open Field


let n_neuron = 100

let make_random_pattern n =
  map (fun _ -> if Random.bool () then 1. else -1.) (make_list n)

let node_patterns = Array.init n_node (fun _ -> make_random_pattern n_neuron)

let node_pattern_list =  map (fun _ -> make_random_pattern n_neuron) (make_list n_node)

let learn nn () =
  ignore(map_adjoining_pair (memorize nn) (take 10 node_pattern_list))


let iter_sp f sp = function
    [] -> ()
  | x::xs ->
      f x;
      List.iter (fun x -> sp (); f x) xs

let print_float_list xs =
  let print_tab () = print_string "\t" in
  iter_sp print_float print_tab xs;
  print_newline ()

let rec repeat f n =
  if n = 0
  then ()
  else (f ();
	repeat f (n-1))

let remember nn () =
  step nn;
  print_float_list (map (overlap nn) (take 10 node_pattern_list))

let _ = let nn = init n_neuron in
  repeat (learn nn) 20;
  set nn (hd node_pattern_list);
  repeat (remember nn) 1000
