open Fujii
open List

(*
#load "fujii.cmo";;
*)
  
type nn = {
  n : int;				(* the number of neurons *)
  mutable wss : float list list;	(* weights *)
  mutable us : float list		(* internal states *)
}

let c = 50.
let c' = 10.
let h = 0.5
let k = -1.0
let m = 10
let a = 4
let tau = 0.01
let tau' = 0.0001
let alpha = 0.01

let mul_sum xs ys =
  List.fold_left2 (fun a x y -> a +. x *. y) 0. xs ys

let f u =
  let a = ~-.c *. u in
  let a' = c' *. (abs_float u -. h) in
    (1. -. exp a) *. (1. +. k *. exp a') /. (1. +. exp a) /. (1. +. exp a')

let rec make_smooth_pattern a x y = 
  if a = 1
  then [x]
  else
    let count_diff x y =
      List.fold_left2 (fun n x y -> if x = y then n else n+1) 0 x y in
    let turn x y n =
      let i = ref 0 in
	List.map2
	  (fun x y ->
	     if x = y or !i >= n
	     then x
	     else (incr i; y))
	  x y in
    let next x y a =
      turn x y (count_diff x y / a) in
      x :: make_smooth_pattern (a-1) (next x y a) y
  
let init n =
  {n = n;
   wss = map (fun _ -> map (fun _ -> 0.) (make_list n)) (make_list n);
   us = map (fun _ -> 0.) (make_list n)
  }
	   
let set nn pattern =
  nn.us <- map (fun x -> x *. h *. 0.5) pattern

let step_1 nn =
  let make_ys = List.map f in
  let make_vs ys = List.map (mul_sum ys) nn.wss in
  let next_us us = 
    let ys = make_ys us in
    let vs = make_vs ys in
      List.map2 (fun u v -> u +. (v -. u) *. tau) us vs in
    nn.us <- next_us nn.us

let step_2 nn =
  let ys = map f nn.us in
  nn.us <- map2 (fun u ws -> u +. (mul_sum ys ws -. u) *. tau) nn.us nn.wss

let step = step_2

let get_xs nn =
  let make_xs =
    let step x =
      if x >= 0.
      then 1.
      else -1. in
      List.map step in
    make_xs nn.us

let overlap nn pattern =
  mul_sum (get_xs nn) pattern /. float_of_int nn.n

let memorize nn from dist =
  let sp = make_smooth_pattern a from dist in
  let add = List.map2 (List.map2 (+.)) in
  let ss0_ss1 ss0 ss1 = List.map (fun s1 -> List.map (fun s0 -> s1 *. s0) ss0) ss1 in
  let w_div w = w /. float_of_int nn.n /. float_of_int a *. alpha in
  let wss' = add (List.map (List.map (fun w -> -.w *. tau')) nn.wss)
	       (List.map (List.map w_div) (fold_left' add (map_adjoining_pair ss0_ss1 sp))) in
    nn.wss <- add nn.wss wss'



(*  *)
