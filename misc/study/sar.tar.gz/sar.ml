open Printf
open Fujii

(*
#load "fujii.cmo";;
#load "am.cmo";;
*)

type action = Action of int * int

let automaton = [|
  [Action (1, -1); Action (2, -1)];
  [Action (0, 0); Action (0, 1)];
  [Action (0, 2); Action (0, 3)];
|]

let _ = Random.self_init ()

let n_neuron_state = 100
let n_neuron_action = 100
let n_neuron_reward = 100
let n_state = 3
let n_action = 2
let n_reward = 4

let make_random_pattern n =
  Array.init n (fun _ -> if Random.bool () then 1. else -1.)

let state_patterns = Array.init n_state (fun _ -> make_random_pattern n_neuron_state)
let action_patterns = Array.init n_action (fun _ -> make_random_pattern n_neuron_action)
let reward_patterns = Array.init n_reward (fun _ -> make_random_pattern n_neuron_reward)

let msa_overlaps = Array.make n_action 0.
let msr_overlaps = Array.make n_reward 0.
let lsa_overlaps = Array.make n_action 0.
let lsr_overlaps = Array.make n_reward 0.

let calc_overlaps overlaps am patterns =
  assert ((Array.length overlaps) = (Array.length patterns));
  Array.iteri (fun i p -> overlaps.(i) <- am#overlap p) patterns

let array_max a =
  let max = ref a.(0) in
  let idx = ref 0 in
    for i=1 to Array.length a - 1 do
      if !max < a.(i)
      then (
	max := a.(i);
	idx := i
      )
    done;
    !idx

let state_action am overlaps state_idx =
  am#cue state_patterns.(state_idx);
  calc_overlaps overlaps am action_patterns;
  let idx = array_max overlaps in
    if overlaps.(idx) > 0.3 then
      Some idx
    else
      None

let state_reward am overlaps state_idx =
  am#cue state_patterns.(state_idx);
  calc_overlaps overlaps am reward_patterns;
  let idx = array_max overlaps in
    if overlaps.(idx) > 0.3 then
      Some idx
    else
      None

let random_action () =
  Random.int n_action

let exploratory_random_action action =
  let a = Random.int (n_action-1) in
    if a = action
    then n_action-1
    else a

let action state_idx am_msa am_msr am_lsa am_lsr =
  let ma = state_action am_msa msa_overlaps state_idx in
  let mr = state_reward am_msr msr_overlaps state_idx in
  let la = state_action am_lsa lsa_overlaps state_idx in
  let lr = state_reward am_lsr lsr_overlaps state_idx in
  let int_option_string str = function
      None -> "--"
    | Some a -> str ^ string_of_int a in
  let action_string a = 
    int_option_string "a" a in
  let reward_string r =
    int_option_string "r" r in
  let print_float_array a =
    Array.iter (fun x -> Printf.printf " %.2f" x) a;
    print_newline () in
  let determine ma mr la lr =
    match (ma, mr, la, lr) with
	(Some ma, Some mr, Some la, Some lr) ->
	  if ma = la && mr = lr then
	    if Random.int 5 = 0
	    then (exploratory_random_action ma, "exp rnd")
	    else (la, "mtm=ltm")
	  else if mr < lr
	  then (la, "ltm")
	  else (ma, "mtm")
      | (Some ma, Some mr, _, _) -> (ma, "mtm")
      | (_, _, Some la, Some lr) -> (la, "ltm")
      | (_, _, _, _) -> (random_action (), "rnd") in
    printf "\nnode s%d\n" state_idx;
    Printf.printf "msa %s " (action_string ma); print_float_array msa_overlaps;
    Printf.printf "msr %s " (reward_string mr); print_float_array msr_overlaps;
    Printf.printf "lsa %s " (action_string la); print_float_array lsa_overlaps;
    Printf.printf "lsr %s " (reward_string lr); print_float_array lsr_overlaps;
    match determine ma mr la lr with
	(action, string) ->
	  printf "action a%d by %s\n" action string;
	  action

let propagate_reward am priv next =
  am#cue state_patterns.(next);
  am#memorize state_patterns.(priv) (am#xs ())

let step am_msa am_msr am_lsa am_lsr state_idx =
  let print_reward r =
    if r <> -1 then
      printf "reward: r%d\n" r in
  let a = action state_idx am_msa am_msr am_lsa am_lsr in
    match List.nth automaton.(state_idx) a with
	Action (next_state_idx, reward) ->
	  print_reward reward;
	  am_msa#memorize state_patterns.(state_idx) action_patterns.(a);
	  am_lsa#memorize state_patterns.(state_idx) action_patterns.(a);
	  if reward = -1 then (
	    propagate_reward am_msr state_idx next_state_idx;
	    propagate_reward am_lsr state_idx next_state_idx
	  )
	  else (
	    am_msr#memorize state_patterns.(state_idx) reward_patterns.(reward);
	    am_lsr#memorize state_patterns.(state_idx) reward_patterns.(reward)
	  );
	  next_state_idx

let am_msa = new Am.am n_neuron_state n_neuron_action 1. 0.3
let am_msr = new Am.am n_neuron_state n_neuron_reward 1. 0.3
let am_lsa = new Am.am n_neuron_state n_neuron_action 1. 0.01
let am_lsr = new Am.am n_neuron_state n_neuron_reward 1. 0.01

let run () = iterator 29 (step am_msa am_msr am_lsa am_lsr) 0

let _ = run ()
