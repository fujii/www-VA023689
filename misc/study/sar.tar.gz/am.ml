let mul_sum xs ys =
  let sum = ref 0. in
    for i=0 to Array.length xs - 1 do
      sum := !sum +. xs.(i) *. ys.(i)
    done;
    !sum

let f u =
  if u >= 0. then
    1.
  else
    -1.

class am n_neuron_cue n_neuron_target alpha beta =
object (self)
  val wss =				(* weights *)
    Array.init n_neuron_target (fun _ -> (Array.make n_neuron_cue 0.))
  val xs = Array.make n_neuron_target 0.	(* outputs *)

  (*  method valid_pattern (pattern:float array) =
      Array.length pattern = n
  *)

  method cue pattern =
    Array.iteri (fun i ws -> xs.(i) <- f (mul_sum ws pattern)) wss

  method overlap pattern =
    mul_sum xs pattern /. float_of_int n_neuron_target

  method attenuate_wss () =
    Array.iteri (fun i ws -> 
		   Array.iteri (fun j w -> wss.(i).(j) <- w -. w *. beta) ws)
		   wss

  method memorize cue target =
    self#attenuate_wss ();
    Array.iteri
      (fun i t -> Array.iteri
	 (fun j c -> wss.(i).(j) <- wss.(i).(j) +. c *. t *. alpha)
	 cue) target

  method wss () = wss
  method xs () = xs
end


(*  *)
