open Printf
open Fujii

(*
#load "fujii.cmo";;
#load "am.cmo";;
*)

let _ = Random.self_init ()

let make_random_pattern n =
  Array.init n (fun _ -> if Random.bool () then 1. else -1.)

let make_zero_pattern n =
  Array.init n (fun _ -> 0.)

let make_array_random array =
  Array.iteri (fun i _ -> array.(i) <- if Random.bool () then 1. else -1.) array

let sum xs = List.fold_left (+.) 0.0 xs

let memory_rate n_test n_neuron n_pair alpha beta flag n_memorize n_memorize_ow =
  let n_neuron_cue = n_neuron in
  let n_neuron_target = n_neuron in
  let overlap am cue target =
    am#cue cue;
    am#overlap target in
  let cue_patterns =
    List.map (fun _ -> make_zero_pattern n_neuron_cue) (make_list n_pair) in
  let target_patterns =
    List.map (fun _ -> make_zero_pattern n_neuron_target) (make_list n_pair) in
  let rec iter am n_test sum = match n_test with
      0 -> sum
    | _ ->
	let ow_cue = make_random_pattern n_neuron_cue in
	let ow_target = make_random_pattern n_neuron_target in
	  List.iter make_array_random cue_patterns;
	  List.iter make_array_random target_patterns;
	  iterator n_memorize (fun () -> List.iter2 am#memorize cue_patterns target_patterns) ();
	  iterator n_memorize_ow (fun () -> am#memorize ow_cue ow_target) ();
	  iter am (n_test-1)
	    (List.fold_left2
	       (fun a c t -> overlap am c t +. a) 0. cue_patterns target_patterns +. sum) in 
  let am = new Am.am n_neuron_cue n_neuron_target alpha beta flag in
    iter am n_test 0. /. float n_test /. float n_pair
    
let n_test = 10
let n_neuron = 100
let n_pair = 50

let print_memory_rates n_neuron n_pair alpha beta n_memorize n_memorize_ow =
  let momory_rate_1 s = memory_rate n_test n_neuron n_pair alpha beta s n_memorize n_memorize_ow in
    printf "%f %f %f\n" (momory_rate_1 1) (momory_rate_1 2) (momory_rate_1 3);
    flush stdout

let run_3 () =
  let test n_memorize = print_memory_rates n_neuron n_pair 1.0 0.01 n_memorize 0 in
  let print n =
    printf "%d " n;
    test n in
    List.iter (fun n -> print (n+1)) (make_list 10)
    
let run_4 () =
  let test n_memorize_ow = print_memory_rates n_neuron n_pair 1.0 0.01 5 n_memorize_ow in
  let print n =
    printf "%d " n;
    test n in
    List.iter (fun n -> print (n*5)) (make_list 10)

let run_5 () =
  let test n_neuron n_pair = print_memory_rates n_neuron n_pair 1.0 0.01 5 0 in
  let print n =
    printf "%d " (n*2);
    test (n*2) (n*1) in
    List.iter (fun n -> print ((n+1)*50)) (make_list 10)

let _ = run_4 ()
