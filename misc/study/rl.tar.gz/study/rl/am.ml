open Fujii

let c = 50.
let c' = 10.
let h = 0.5
let k = -1.0
let tau = 0.01

let mul_sum xs ys =
  let sum = ref 0. in
    for i=0 to Array.length xs - 1 do
      sum := !sum +. xs.(i) *. ys.(i)
    done;
    !sum

let f u =
  let a = ~-.c *. u in
  let a' = c' *. (abs_float u -. h) in
    (1. -. exp a) *. (1. +. k *. exp a') /. (1. +. exp a) /. (1. +. exp a')

class am n_neuron alpha =
object (self)
  val n = n_neuron			(* the number of neurons *)
  val alpha = alpha			(* learning rate *)
		(* val n_turn = max (n_neuron / 10) 1 *)
  val mutable wss =			(* weights *)
    Array.init n_neuron (fun _ -> (Array.make n_neuron 0.))
  val mutable us = Array.make n_neuron 0. (* internal states *)
  val mutable ys = Array.make n_neuron 0. (* outputs *)
  val mutable xs = Array.make n_neuron 0. (* outputs *)
  val mutable vs = Array.make n_neuron 0. (* vector *)

  method valid_pattern (pattern:float array) =
    Array.length pattern = n

  method calc_output () =
    for i=0 to n-1 do
      ys.(i) <- f us.(i);
      xs.(i) <- if us.(i) >= 0. then 1. else -1.
    done;
    for i=0 to n-1 do
      vs.(i) <- mul_sum ys wss.(i) /. float_of_int n *. alpha
    done

  method cue pattern =
    for i=0 to n-1 do
      us.(i) <- pattern.(i) *. h *. 0.2
    done;
    self#calc_output ()

  method step () =
    for i=0 to n-1 do
      us.(i) <- us.(i) +. (vs.(i) -. us.(i)) *. tau
    done;
    self#calc_output ()

  method overlap pattern =
    mul_sum xs pattern /. float_of_int n

  method memorize =
    let f = Array.make n_neuron 0. in
    let d = Array.make n_neuron 0. in
      fun from dist ->
	let count_diff x y =
	  let rv = ref 0 in
            for i=0 to n-1 do
              if x.(i) <> y.(i)
              then incr rv
            done;
            !rv in
	let attenuate_wss () =
          for i=0 to n-1 do
            for j=0 to n-1 do
              let w = wss.(i).(j) in
		wss.(i).(j) <- w +. (-.w) *. 0.01
            done
          done in
	let memorize_i a from dist =
	  for i = 0 to n-1 do
	    for j = 0 to n-1 do
	      let w' = from.(j) *. dist.(i) /. float_of_int a in
	      let w = wss.(i).(j) in
		wss.(i).(j) <- w +. w'
	    done
	  done in
	let n_diff = count_diff from dist in
	let a = max (round (float n_diff *. 10. /. float n )) 1 in
	let n_turn = int_of_float (ceil (float n_diff /. float a)) in
	  attenuate_wss ();
	  for i=0 to n-1 do
	    f.(i) <- from.(i);
	    d.(i) <- from.(i)
	  done;
	  let rest = ref n_turn in
	    for i=0 to n-1 do
	      if f.(i) <> dist.(i) then (
		decr rest;
		d.(i) <- dist.(i);
		if !rest = 0 then (
		  rest := n_turn;
		  memorize_i a f d;
		  for j=0 to i do
		    f.(j) <- d.(j)
		  done
		)
	      )
	    done;
	    if !rest <> n_turn then
	      memorize_i a f d

  method get_wss () = wss
  method get_us () = us
  method get_ys () = ys
  method get_xs () = xs
  method get_vs () = vs
end

(*
let from = [|-1.;1.|]
let dist = [|1.;-1.|]
let am = new am 2 0.01;;
am#memorize from dist;;
am#get_wss ();;

let n=10
let am = new am 10 0.01
let from = make_random_pattern n
let dist = make_random_pattern n;;
am#mem from dist;;
;;
*)


(*  *)
