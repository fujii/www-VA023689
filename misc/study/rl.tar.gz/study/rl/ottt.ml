let _ = Random.self_init ()

(* tic-tac-toe *)
class ttt =
  let length = 3 in
object (self)
  val board = Array.init length (fun _ -> Array.make length 0)
  method length = length
  method set x y t =
    board.(x).(y) <- t;
  method clear () =
    for y=0 to length-1 do
      for x=0 to length-1 do
	self#set x y 0
      done
    done
  method get x y =
    board.(x).(y)
  method judge () =
    let j = ref 0 in
      (try
	 for y=0 to length-1 do
	   j := 0;
	   for x=0 to length-1 do
	     j := !j + self#get x y
	   done;
	   if !j = length || !j = -length
	   then raise Exit
	 done;
	 for x=0 to length-1 do
	   j := 0;
	   for y=0 to length-1 do
	     j := !j + self#get x y
	   done;
	   if !j = length || !j = -length
	   then raise Exit
	 done;
	 j := 0;
	 for i=0 to length-1 do
	   j := !j + self#get i i
	 done;
	 if !j = length || !j = -length
	 then raise Exit;
	 j := 0;
	 for i=0 to length-1 do
	   j := !j + self#get i (length-i-1)
	 done;
	 if !j = length || !j = -length
	 then raise Exit;
	 j := 0
       with Exit ->
	 j := !j / 3);
      !j
  method print () =
    print_newline ();
    for y=0 to length-1 do
      for x=0 to length-1 do
	print_string
	  (match self#get x y with
	       0 -> "."
	     | 1 -> "o"
	     | -1 -> "x"
	     | _ -> failwith "ttt#print")
      done;
      print_newline ()
    done
  method count_empty_box () =
    let sum = ref 0 in
      for y=0 to length-1 do
	for x=0 to length-1 do
	  if self#get x y = 0
	  then sum := !sum + 1
	done
      done;
      !sum
  method random_move () =
    let count = self#count_empty_box () in
      if count = 0 then
	failwith "random_move";
      let rv = ref (0, 0) in
      let rnd = ref (Random.int count) in
	(try
	   for y=0 to length-1 do
	     for x=0 to length-1 do
	       if self#get x y = 0 then 
		 rnd := !rnd - 1;
	       if !rnd < 0 then (
		 rv := (x, y);
		 raise Exit
	       )
	     done
	   done
	 with
	     Exit -> ());
	!rv
	  

(*
  method
  for y=0 to length-1 do
  for x=0 to length-1 do
  done
  done
*)    
end

let test_1 () =
  let ttt = new ttt in
    for x=0 to ttt#length -1 do
      ttt#set 2 2 (-1)
    done;
    ttt#print ();
    ttt#judge ()

(*
let test_1 () =
  let ttt = new ttt in
  let rec iter () =
    ttt#random_move 1;
    ttt#print ();
    ttt#random_move (-1);
    ttt#print ();
    iter () in
    iter ()
*)

let ttt_equal_p ttt_a ttt_b =
  let length = ttt_a#length in
  let rv = ref true in
    (try
       for y=0 to length-1 do
	 for x=0 to length-1 do
	   if ttt_a#get x y <> ttt_b#get x y then
	     raise Exit
	 done
       done
     with
	 Exit -> rv := false
    );
    !rv

let ttt_copy ttt_from ttt_to =
  let length = ttt_from#length in
    for y=0 to length-1 do
      for x=0 to length-1 do
	ttt_to#set x y (ttt_from#get x y)
      done
    done


let n_neuron_per_box = 10
let n_neuron_board = n_neuron_per_box * 3 * 3
let n_neuron_reward = 10
let n_neuron = n_neuron_board + n_neuron_reward
let s_am = new Am.am n_neuron 0.7
let l_am = new Am.am n_neuron 0.001


let from_pattern = Array.make n_neuron 0.
let dist_pattern = Array.make n_neuron 0.

(* let box_patterns = [|[|1.;-1.;-1.|];[|-1.;1.;-1.|];[|-1.;-1.;1.|]|]
let reward_patterns = [|[|1.;-1.;-1.|];[|-1.;-1.;1.|]|] *)

let make_random_pattern n =
  Array.init n (fun _ -> if Random.bool () then 1. else -1.)

let box_patterns = Array.init 3 (fun _ -> make_random_pattern n_neuron_per_box)
let reward_patterns = Array.init 2 (fun _ -> make_random_pattern n_neuron_reward)

let board_to_pattern pattern ttt =
  let length = ttt#length in
    for y=0 to length-1 do
      for x=0 to length-1 do
	let box_pattern = box_patterns.(
	  match ttt#get x y with
	      1 -> 0
	    | -1 -> 1
	    | 0 -> 2
	    | _ -> 2) in
	  for i=0 to n_neuron_per_box-1 do
	    pattern.((y*length + x)*n_neuron_per_box + i) <- box_pattern.(i)
	  done
      done
    done

let make_pattern pattern ttt reward =
  board_to_pattern pattern ttt;
  for i=0 to n_neuron_reward-1 do
    pattern.(n_neuron_board + i) <- reward_patterns.(reward).(i)
  done

let test_2 () = 0

let ttt = new ttt
let pttt = new ttt 			(* previous *)

let count_match xs idx pattern =
  let sum = ref 0 in
    for i=0 to Array.length pattern - 1 do
      if xs.(idx + i) = pattern.(i)
      then sum := !sum + 1
    done;
    !sum

let test_3 () =
  count_match box_patterns.(0) 0 box_patterns.(0)

let max_pattern xs idx patterns =
  let max_idx = ref 0 in
  let max = ref (count_match xs idx patterns.(0)) in
    for p=1 to Array.length patterns - 1 do
      let cur = count_match xs idx patterns.(p) in
	if cur > !max then (
	  max_idx := p;
	  max := cur
	)
    done;
    !max_idx

let xs_to_ttt xs ttt = 
  let length = ttt#length in
    for y=0 to length-1 do
      for x=0 to length-1 do
	ttt#set x y 
	  (match max_pattern xs ((y*length+x)*n_neuron_per_box) box_patterns with
	       0 -> 1
	     | 1 -> -1
	     | _ -> 0)
      done
    done;
    max_pattern xs (n_neuron_board) reward_patterns

let remember =
  let pattern = Array.make n_neuron 0. in
  let ttt_pre = ref new ttt in
  let ttt_cur = ref new ttt in
  let reward = ref false in
    fun ttt_cue am ->
      let rec iter n =
	am#step ();
	if xs_to_ttt (am#get_xs ()) !ttt_cur = 1 then
	  reward := true;
	if not (ttt_equal_p !ttt_pre !ttt_cur) then (
	  !ttt_cur#print ();
	  (let t = !ttt_pre in
	     ttt_pre := !ttt_cur;
	     ttt_cur := t)
	);
	if n > 0 then
	  iter (n-1) in
	ttt_copy ttt_cue !ttt_pre;
	make_pattern pattern ttt_cue 0;
	am#cue pattern;
	iter 1000

let calc_next ttt s_am l_am =
  ttt#random_move ()

let main () =
  let rec iter turn previous_x previous_y previous_turn =
    match calc_next ttt s_am l_am with
	(x, y) -> ttt#set x y turn;
	  let judge = ttt#judge () in
	    make_pattern from_pattern pttt (if judge = turn then 1 else 0);
	    make_pattern dist_pattern ttt (if judge = turn then 1 else 0);
	    s_am#memorize from_pattern dist_pattern;
	    l_am#memorize from_pattern dist_pattern;
	    ttt#print ();
	    pttt#set previous_x previous_y previous_turn;
	    if judge = 0 && ttt#count_empty_box () > 0 then
	      iter (turn * -1) x y turn
	    else (
	      print_int judge;
	      print_newline ();
	    ) in
    ttt#clear ();
    pttt#clear ();
    iter 1 0 0 0

let rec repeat f n =
  if n = 0
  then ()
  else (f ();
	repeat f (n-1))

let _ = repeat main 3;
  let ttt = new ttt in
    print_string "remember\n";
    remember ttt s_am
