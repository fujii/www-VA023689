
let automaton = [|
  [1;2];
  [3;4];
  [5;6];
  [7];
  [8];
  [9];
  [10];
|]

let is_terminal idx = idx >= 3 
let is_reward idx = idx >= 7

let _ = Random.self_init ()

let n_neuron = 100
let n_node = 11

let make_random_pattern n =
  Array.init n (fun _ -> if Random.bool () then 1. else -1.)

let node_patterns = Array.init n_node (fun _ -> make_random_pattern n_neuron)

let node_overlaps = Array.init n_node (fun _ -> 0.)

let calc_node_overlaps am =
  for i=0 to n_node-1 do
    node_overlaps.(i) <- am#overlap node_patterns.(i)
  done

let array_max a =
  let max = ref a.(0) in
  let idx = ref 0 in
    for i=1 to Array.length a - 1 do
      if !max < a.(i)
      then (
	max := a.(i);
	idx := i
      )
    done;
    !idx

let recall am start_idx time =
  let idx_list = ref [] in
  let current_idx = ref start_idx in
    am#cue node_patterns.(start_idx);
    for i=1 to time do
      am#step ();
      calc_node_overlaps am;
      let max_idx = array_max node_overlaps in
	if !current_idx <> max_idx
	then (
	  current_idx := max_idx;
	  idx_list := !current_idx::!idx_list
	)
    done;
    List.rev !idx_list

let safe_hd lst =
  match lst with
      [] -> None
    | x::xs -> Some x

let rl_next rl idx =
  match safe_hd rl with
      None -> None
    | Some x ->
	if List.mem x automaton.(idx) then
	  Some x
	else
	  None

let rec rl_reward rl =
  match rl with
      [] -> None
    | x::xs ->
	if is_reward x then
	  Some x
	else
	  rl_reward xs

let random_move idx =
  let lst = automaton.(idx) in
    List.nth lst (Random.int 2)

let iter_sp f sp = function
    [] -> ()
  | x::xs ->
      f x;
      List.iter (fun x -> sp (); f x) xs

let print_x_list print_x xs =
  let print_tab () = print_string " " in
  iter_sp print_x print_tab xs;
  print_newline ()

let print_float_list = print_x_list print_float
let print_int_list = print_x_list print_int

let print_option_int x =
  match x with
      None -> print_string "-"
    | Some x -> print_int x

let determine idx stm ltm =
  let rl_s = recall stm idx 2000 in
  let rl_l = recall ltm idx 2000 in
  let next_s = rl_next rl_s idx in
  let next_l = rl_next rl_l idx in
  let reward_s = rl_reward rl_s in
  let reward_l = rl_reward rl_l in
  let d_random () =
    let i = random_move idx in
      print_string "rnd ";
      print_int i;
      print_newline ();
      i in
  let d_short_or_long lbl opt_i =
    let i = match opt_i with Some i -> i | None -> failwith "" in
      print_string lbl;
      print_int i;
      print_newline ();
      i in
  let d_short () = d_short_or_long "stm " next_s in
  let d_long () = d_short_or_long "ltm " next_l in
    print_string " stm: ";print_option_int next_s;print_string ", ";
    print_option_int reward_s;print_string ", ";
    print_int_list rl_s;
    print_string " ltm: ";print_option_int next_l;print_string ", ";
    print_option_int reward_l;print_string ", ";
    print_int_list rl_l;
    (* print_newline (); *)
    print_string " choise: ";
    match (next_s, next_l, reward_s, reward_l) with
	(Some ns, Some nl, Some rs, Some rl) ->
	  if ns = nl && rs = rl then
	    if Random.int 10 = 0 then
	      d_random ()
	    else
	      d_long ()
	  else if rs < rl then
	    d_long ()
	  else
	    d_short ()
      |	(Some ns, _, Some rs, None) -> d_short ()
      | (_, Some nl, None, Some rl) -> d_long ()
      | (Some ns, None, Some rs, _) -> d_short ()
      | (None, Some nl, _, Some rl) -> d_long ()
      | (_, _, _, _) -> d_random ()



	  
    
let tree stm ltm =
  let rec iter idx =
    let next_idx = determine idx stm ltm in
      print_string "node: ";print_int next_idx;print_newline ();
      stm#memorize node_patterns.(idx) node_patterns.(next_idx);
      ltm#memorize node_patterns.(idx) node_patterns.(next_idx);
      if is_terminal next_idx then
	let reward_idx = List.hd automaton.(next_idx) in
	  stm#memorize node_patterns.(next_idx) node_patterns.(reward_idx);
	  ltm#memorize node_patterns.(next_idx) node_patterns.(reward_idx);
      else
	iter next_idx in
    print_string "\nnode: 0\n";
    iter 0
	  
      
let stm = new Am.am n_neuron 0.1
let ltm = new Am.am n_neuron 0.01

let main () =
  tree stm ltm

let rec repeat f n =
  if n = 0
  then ()
  else (f ();
	repeat f (n-1))

let _ = repeat main 20
