open Nm

let time = ref 30

let speclist = ["-time", Arg.Int (fun x -> time := x), "times of iteration";
	        "-n", Arg.Int (fun x -> n := x), "neurons"]

let _ = Arg.parse speclist ignore "time"

let _ = iterator !time main init_us
