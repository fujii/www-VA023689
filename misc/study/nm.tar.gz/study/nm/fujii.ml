let rec take n = function
    [] -> []
  | x::xs -> if n=0
    then []
    else x :: (take (n-1) xs)

let rec make_list n = 
  let i = ref (n-1) in
  let list = ref [] in
    while !i >= 0 do
      list := !i :: !list;
      decr i
    done;
    !list

let gen_list start next last = 
  if start = next
  then failwith "gen_list: next is equal to start"
  else
  let i = ref start in
  let list = ref [] in
  let step = next - start in
  let cont =
    if step > 0
    then fun i -> i <= last
    else fun i -> i >= last in
    begin
      while cont !i do
	list := !i :: !list;
	i := !i + step;
      done;
      List.rev !list
    end

let rec pow_int x n =
  let square x = x * x in
    if n = 0
    then 1
    else if n land 1 = 0
    then square (pow_int x (n/2))
    else (pow_int x (n-1)) * x
