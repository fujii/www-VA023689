
let _ = Random.self_init ()

class tree n_a depth =
  let rec calc_n_node n_a depth =
    match depth with
	0 -> 1
      | d -> n_a * (calc_n_node n_a (d-1)) + 1 in
  let n_node = calc_n_node n_a depth in

  let child = Array.init n_node (fun _ -> Array.make n_a 0) in
  let rec make_child child n_a depth index =
    if depth = 0
    then
      index
    else
      let i = ref index in
	for a=0 to n_a-1 do
	  incr i;
	  child.(index).(a) <- !i;
	  i := make_child child n_a (depth-1) !i;
	done;
	!i in
  let _ = make_child child n_a depth 0 in

  let node_str = Array.make n_node "x" in
  let rec make_node_str node depth str =
    node_str.(node) <- str;
    if depth > 0 then
      for i=0 to n_a-1 do
	make_node_str child.(node).(i) (depth-1) (Printf.sprintf "%s-%d" str i)
      done in
  let _ = make_node_str 0 depth "R" in
    
  let reward = Array.init n_node (fun _ -> Array.make n_a 0) in
  let rec make_reward node depth r =
    if depth = 0 then (
      let a = Random.int n_a in
      reward.(node).(a) <- r;
      Printf.printf "Reward: %d %s-%d\n" r node_str.(node) a
    ) else
      make_reward child.(node).(Random.int n_a) (depth-1) r in
  let _ = make_reward 0 depth 30 in
  let _ = make_reward 0 depth 30 in
  let _ = make_reward 0 depth 30 in
  let _ = make_reward 0 depth 50 in

object (self)
  val mutable cur_node = 0

  method child = child
  method reward = reward
  method n_node = n_node
  method cur_node () = cur_node
  method cur_node_str () = node_str.(cur_node)
			     
  method step a =
    let pre_node = cur_node in
      assert (a >= 0 && a < n_a);
      cur_node <- child.(cur_node).(a);
      reward.(pre_node).(a)
end
