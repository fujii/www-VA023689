(*
#load "fujii.cmo";;
#load "am.cmo";;
*)
  


let meth = 4				(* method *)
let flag_print = false

class sar n_neuron_s a_pats n_neuron_r m_alpha m_beta l_alpha l_beta gamma =
object (self)
  val n_a = Array.length a_pats
  val m_sa = new Am.am n_neuron_s (Array.length a_pats.(0)) m_alpha m_beta meth
  val l_sa = new Am.am n_neuron_s (Array.length a_pats.(0)) l_alpha l_beta meth
  val m_sr = new Am.nam2 n_neuron_s n_neuron_r m_alpha m_beta meth
  val l_sr = new Am.nam2 n_neuron_s n_neuron_r l_alpha l_beta meth
  val mutable pre_s = None
  val pre_s_pat = Array.make n_neuron_s 0.
  val mutable a = -1
  val mutable why_a = "-"

  method a () = a
  method why_a () = why_a

  (*
    val mutable print_a_str = fun a str -> ()
    method set_print_a_str fn = print_a_str <- fn
  *)

  method think_a r s =
    let recall am cue pats =
      am#recall cue;
      let max_i = ref 0 in
      let max = ref (am#overlap pats.(0)) in
	for i=1 to Array.length pats - 1 do
	  if !max < am#overlap pats.(i) then (
	    max_i := i;
	    max := am#overlap pats.(i)
	  )
	done;
	if !max > 0.3
	then Some !max_i
	else None in

    (* random action. return the index of action *)
    let rand_a () = Random.int n_a in

    (* like rand_a except ex_a won't be selected. *)
    let rand_a_ex ex_a =
      let a = Random.int (n_a-1) in
	if a = ex_a
	then n_a-1
	else a in

    let determine ma mr la lr =
      let intstr x =
	match x with
	    Some x -> string_of_int x
	  | None -> "-" in
      let why = Printf.sprintf " ma=%s mr=%-3d la=%s lr=%-3d" (intstr ma) mr (intstr la) lr in
	match (ma, la) with
	    (Some ma, Some la) ->
	      if ma = la then
		if Random.int 10 = 0
		then (rand_a_ex ma, "explore" ^ why)
		else (la, "mtm=ltm" ^ why)
	      else if mr < lr
	      then (la, "ltm>mtm" ^ why)
	      else (ma, "mtm>ltm" ^ why)
	  | (Some ma, None) -> (ma, "mtm    " ^ why)
	  | (None, Some la) -> (la, "ltm    " ^ why)
	  | (None, None) -> (rand_a (), "random " ^ why) in

    let memorize_sr nam s_pre s_cur r =
      let r_cur = match s_cur with
	  None -> 0.
	| Some s -> float (nam#recall s) in
      let r = match r with
	  None -> 0.
	| Some r -> float r in
      let r_mix = r +. gamma *. r_cur in
      let r_mix_int =
	if r_mix < 0. then 0
	else if r_mix > float n_neuron_r then n_neuron_r
	else int_of_float r_mix in
	nam#memorize pre_s_pat r_mix_int in

      if flag_print then begin
	(match pre_s with
	     None -> ()
	   | Some s -> Printf.printf " pre: mr=%d lr=%d" (m_sr#recall s) (l_sr#recall s));
	(match s with
	     None -> print_newline ()
	   | Some s -> Printf.printf " cur: mr=%d lr=%d\n" (m_sr#recall s) (l_sr#recall s));
      end;

      (* s��r �ؤε��� *)
      (match pre_s with
	   Some pre_s_pat ->
	     memorize_sr m_sr pre_s_pat s r;
	     memorize_sr l_sr pre_s_pat s r;
	 | None -> ());

      if flag_print then begin
	(match pre_s with
	     None -> ()
	   | Some s -> Printf.printf " pre: mr=%d lr=%d" (m_sr#recall s) (l_sr#recall s));
	(match s with
	     None -> print_newline ()
	   | Some s -> Printf.printf " cur: mr=%d lr=%d\n" (m_sr#recall s) (l_sr#recall s));
      end;

      (* s �� pre_s ����¸ *)
      (match s with
	   None -> pre_s <- None
	 | Some s_pat ->
	     pre_s <- Some pre_s_pat;
	     Array.iteri (fun i s -> pre_s_pat.(i) <- s_pat.(i)) s_pat);
      (* s ����۵�����ư�η��� *)
      (match s with
	   None ->
	     a <- -1;
	     why_a <- "-"
	 | Some s_pat ->
	     match (determine (recall m_sa s_pat a_pats) (m_sr#recall s_pat)
		      (recall l_sa s_pat a_pats) (l_sr#recall s_pat)) with
		 (aa, str) -> 
		   m_sa#memorize s_pat a_pats.(aa);
		   l_sa#memorize s_pat a_pats.(aa);
		   a <- aa;
		   why_a <- str);
      a
end

(* test *)
open Fujii
open Printf

let _ = Random.self_init ()

let make_random_pat n =
  Array.init n (fun _ -> if Random.bool () then 1. else -1.)

(* state��1�� *)
let test () =
  let n_neuron_s = 50 in
  let n_a = 5 in
  let a_pats = Array.init n_a (fun _ -> make_random_pat 51) in
  let s_pat = make_random_pat n_neuron_s in
  let m_alpha = 0.5 in
  let m_beta = m_alpha in
  let l_alpha = 0.05 in
  let l_beta = l_alpha in
  let sar = new sar n_neuron_s a_pats 52 m_alpha m_beta l_alpha l_beta 0.8 in
  let iter r =
    let a = sar#think_a r (Some s_pat) in
    Some a in
    (* sar#set_print_a_str (Printf.printf "%d %s \n"); *)
    iterator 200 iter None
      

(* let _ = test () *)

(*
let calc_overlaps overlaps am patterns =
  assert ((Array.length overlaps) = (Array.length patterns));
  Array.iteri (fun i p -> overlaps.(i) <- am#overlap p) patterns

let array_max a =
  let max = ref a.(0) in
  let idx = ref 0 in
    for i=1 to Array.length a - 1 do
      if !max < a.(i)
      then (
	max := a.(i);
	idx := i
      )
    done;
    !idx

let state_action am overlaps state_idx =
  am#cue state_patterns.(state_idx);
  calc_overlaps overlaps am action_patterns;
  let idx = array_max overlaps in
    if overlaps.(idx) > 0.3 then
      Some idx
    else
      None

let state_reward am overlaps state_idx =
  am#cue state_patterns.(state_idx);
  calc_overlaps overlaps am reward_patterns;
  let idx = array_max overlaps in
    if overlaps.(idx) > 0.3 then
      Some idx
    else
      None
*)
