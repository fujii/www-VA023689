(* ���� *)
let mul_sum xs ys =
  let sum = ref 0. in
    for i=0 to Array.length xs - 1 do
      sum := !sum +. xs.(i) *. ys.(i)
    done;
    !sum

let f u =
  if u >= 0.
  then 1.
  else -1.

class am n_neuron_cue n_neuron_target alpha beta memorize_method =
  let valid_cue_pat pat =
    Array.length pat = n_neuron_cue in
  let valid_target_pat pat =
    Array.length pat = n_neuron_target in
object (self)
  val wss =				(* weights *)
    Array.init n_neuron_target (fun _ -> (Array.make n_neuron_cue 0.))

(*
  val wss =				(* weights *)
    Array.init n_neuron_target (fun _ -> (Array.make n_neuron_cue (Random.float 2. -. 1.)))
*)
  val xs = Array.make n_neuron_target 0. (* outputs *)

  method wss () = wss
  method xs () = xs

  method reinit	() =
    Array.iteri (fun i ws -> Array.iteri (fun j _ -> wss.(i).(j) <- 0.) ws) wss

(*
  method reinit_random () =
    let random_float () = Random.float 2. -. 1. in
      Array.iteri (fun i ws -> Array.iteri (fun j _ -> wss.(i).(j) <- random_float ()) ws) wss
*)
  method recall cue =
    assert (valid_cue_pat cue);
    Array.iteri (fun i ws -> xs.(i) <- f (mul_sum ws cue)) wss

  method overlap pat =
    mul_sum xs pat /. float_of_int n_neuron_target

  method memorize_1 cue target =
    assert (valid_cue_pat cue);
    assert (valid_target_pat target);
    Array.iteri
      (fun i t -> Array.iteri
	 (fun j c -> wss.(i).(j) <-
	    wss.(i).(j) +. c *. t *. alpha -. wss.(i).(j) *. beta)
	 cue) target

  method memorize_2 cue target =
    assert (valid_cue_pat cue);
    assert (valid_target_pat target);
    self#recall cue;
    Array.iteri
      (fun i t -> 
	 if t <> xs.(i) then
	   Array.iteri
	     (fun j c -> wss.(i).(j) <- wss.(i).(j) +. c *. t *. alpha -. wss.(i).(j) *. beta)
	     cue) target

  method memorize_3 cue target =
    assert (valid_cue_pat cue);
    assert (valid_target_pat target);
    Array.iteri
      (fun i t -> 
	 let ms = mul_sum wss.(i) cue -. t in
	   if t *. ms < 0. then
	     let d_w = -. ms /. float n_neuron_cue *. alpha in
	       Array.iteri
		 (fun j c -> wss.(i).(j) <- wss.(i).(j) +. c *. d_w -. wss.(i).(j) *. beta)
		 cue) target

  method memorize_4 cue target =
    assert (valid_cue_pat cue);
    assert (valid_target_pat target);
    Array.iteri
      (fun i t -> 
	 let ms = mul_sum wss.(i) cue in
	   if t *. ms /. float n_neuron_cue < 1.0 then
	     Array.iteri
	       (fun j c -> wss.(i).(j) <- wss.(i).(j) +. c *. t *.alpha -. wss.(i).(j) *. beta)
	       cue) target

  method memorize =
    match memorize_method with
	1 -> self#memorize_1
      | 2 -> self#memorize_2
      | 3 -> self#memorize_3
      | 4 -> self#memorize_4
      | _ -> failwith "memorize"
end

(*
let float_to_pat f low high pat =
  let len = Array.length pat in
  let int = int_of_float ((f -. low) *. float len /. (high -. low)) in
    for i=0 to int-1 do
      pat.(i) <- 1.
    done;
    for i=int to len-1 do
      pat.(i) <- -1.
    done
*)

let num_to_pat num pat =
  let len = Array.length pat in
    if num < 0 or num > len then raise (Invalid_argument "num_to_pat: out of range: num");
    for i=0 to num-1 do
      pat.(i) <- 1.
    done;
    for i=num to len-1 do
      pat.(i) <- -1.
    done

let pat_to_num pat =
  let num = ref 0 in
  let incr_num e = if e > 0. then incr num in
    Array.iter incr_num pat;
    !num


(* �ѥ����󤫤����ѥ�����ؤ�Ϣ�۵���
 *)

class pam n_neuron_cue n_neuron_target n_target alpha beta memorize_method =
  let _ = Random.self_init () in
  let make_random_pat n =
    Array.init n (fun _ -> if Random.bool () then 1. else -1.) in
object (self)
  val am = new am n_neuron_cue n_neuron_target alpha beta memorize_method
  val target_pats = Array.init n_target (fun _ -> make_random_pat n_neuron_target)

  method recall cue =
    let max pats =
      let max_i = ref 0 in
      let max = ref (am#overlap pats.(0)) in
	for i=1 to Array.length pats - 1 do
	  if !max < am#overlap pats.(i) then (
	    max_i := i;
	    max := am#overlap pats.(i)
	  )
	done;
	if !max > 0.3
	then Some !max_i
	else None in
      am#recall cue;
      max target_pats

  method memorize cue target_idx =
    am#memorize cue target_pats.(target_idx)
      
end


(* �ѥ����󤫤���ͤؤ�Ϣ�۵���
 * ���ͤ� 0 ���� n_neuron_target ������
 *)
class nam n_neuron_cue n_neuron_target alpha beta memorize_method =
object (self)
  val am = new am n_neuron_cue n_neuron_target alpha beta memorize_method
  val target_pat = Array.make n_neuron_target 0.

  method recall cue =
    am#recall cue;
    pat_to_num (am#xs ())

  method memorize cue target_num =
    num_to_pat target_num target_pat;
    am#memorize cue target_pat
    
end


(* �ѥ����󤫤�Υ�����ͤؤ�Ϣ�۵���
 * ���ͤ� 0 ���� n_neuron_target ������
 *)
class dnam n_neuron_cue n_neuron_target n_target alpha beta memorize_method =
object (self)
  val am = new pam n_neuron_cue n_neuron_target n_target alpha beta memorize_method

  method recall cue =
    am#recall cue

  method memorize cue target_idx =
    am#memorize cue target_idx
    
end


class nam2 n_neuron_cue n_neuron_target alpha beta memorize_method =
  let denom = 4 in
  let n_target = n_neuron_target / denom in
object (self)
  val am = new dnam n_neuron_cue n_neuron_target n_target alpha beta memorize_method
  method recall cue =
    match am#recall cue with
	Some i -> i * denom
      | None -> 0
      
  method memorize cue target =
    am#memorize cue (target / denom)
end


(*  *)
