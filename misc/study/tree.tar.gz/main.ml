open Printf
open Fujii

(*
#load "fujii.cmo";;
#load "am.cmo";;
#load "sar.cmo";;
*)

let n_neuron_a = 100
let n_neuron_r = 99

let make_random_pattern n =
  Array.init n (fun _ -> if Random.bool () then 1. else -1.)

let depth = 2
let n_a = 4
let a_pats = Array.init n_a (fun _ -> make_random_pattern n_neuron_a)

let tree = new Tree.tree n_a depth

let n_neuron_s = 100
let s_pats = Array.init tree#n_node (fun _ -> make_random_pattern  n_neuron_s)

(*
let exam sar tree =
  let rec iter r s =
    let a = sar#think_a (Some r) (Some s) in
    let r = tree#step a in
      printf "node: %s\n" (tree#cur_node_str ());
      iter r s_pats.(tree#cur_node ()) in
    iter 0 s_pats.(tree#cur_node ())
*)

let exam sar tree =
  let rec iter r = begin
    printf "node: %s\n" (tree#cur_node_str ());
    let a = sar#think_a (Some r) (Some s_pats.(tree#cur_node ())) in
    let r = tree#step a in
      printf " a=%d r=%d %s\n" a r (sar#why_a ());
      r 
  end in
    iterator 1000 iter 0

let _ =
  let gamma = 0.8 in
  let sar = new Sar.sar n_neuron_s a_pats n_neuron_r 0.5 0.5 0.1 0.1 gamma in
    exam sar tree
