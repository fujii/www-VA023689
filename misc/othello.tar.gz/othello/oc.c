/*  
 *    Othello Client   
 */

#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>

#include "othello.h"
#include "setup_client.h"
#include "oth.h"

#define DEFAULT_USER_NAME "e23037"
#define DEFAULT_HOST_NAME "localhost"

int board[BOARD_SIZE][BOARD_SIZE];
char user_name[NAME_LENGTH+1] = DEFAULT_USER_NAME;
char enemy_name[NAME_LENGTH+1];
char host_name[256] = DEFAULT_HOST_NAME;
int user_turn = FIRST;
char *player_name[2];

void think(int board[BOARD_SIZE][BOARD_SIZE],
	   int turn, int count,  int *x, int *y);

void usage(char *prog){
  printf( "\n Othello Client\n\n"
	  "usage:\n"
	  " %s [-1] [host_name] [port_number]\n\n"
          "        -1  �Ǥ���и�ꡣ\n\n"
	  " %s -h\n"
          "          Print this message.\n",
	  prog, prog);
  exit(0);
}

#define BLACK "\033[30;42m��\033[0m"
#define WHITE "\033[37;42m��\033[0m"
#define BOARD "\033[30;42m -\033[0m"

void display(int turn){
  int x, y;
  int s;

  printf("   a b c d e f g h\n");
  y = 0;
  while(1){
    x = 0;
    printf("%2d", y);

    while(1){
      /*s = board[x][y];*/
      s = board[y][x];

      if(s == 1)
	printf(BLACK);
      else if(s == -1)
	printf(WHITE);
      else 
	printf(BOARD);

      x++;
      if(x >= BOARD_SIZE)
	break;
    }
    printf("\n");
    y++;
    if(y >= BOARD_SIZE)
      break;
  }

  printf(BLACK ":���:%s\n", player_name[0]);
  printf(WHITE ":���:%s\n", player_name[1]);
}

int total_stone(int board[BOARD_SIZE][BOARD_SIZE]){
  int result = 0;
  int x, y;

  for(y=0;y<BOARD_SIZE;y++)
    for(x=0;x<BOARD_SIZE;x++)
      if(board[x][y])
	result++;

  return result;
}

int main(int argc, char *argv[]){
  int i, s;
  struct handshake hs;
  u_short port = 0;
  int srv;
  int pos[2];
  int turn, count;

  /* ����� */
  if(getenv("HOST") != NULL)
    strcpy(host_name, getenv("HOST"));
  else if(getenv("HOSTNAME") != NULL)
    strcpy(host_name, getenv("HOSTNAME"));


  /* ���ޥ�ɥ��ץ������� */
  s = 0;
  for(i=1;i<argc;i++){
    if(strcmp("-h", argv[i]) == 0)
      usage(argv[0]);

    switch(s){
    case 0:
      if(strcmp("-1", argv[i]) == 0){
	user_turn = SECOND;
	s++;
	break;
      }else 
	s++;

    case 1:
      if(isalpha(argv[i][0])){
	strcpy(host_name, argv[i]);
	s ++;
	break;
      }else
	s ++;
      
    case 2:
      port = atoi(argv[i]);
      s++;
      break;

    case 3:
      usage(argv[0]);
    }
  }

  while(port == 0){
    fputs("Input the port number :", stdout);
    fflush(stdout);
    scanf("%d", &i);
    port = i;
  }

  printf("user_name:%s\n" ,user_name);
  printf("host_name:%s\n" ,host_name);
  printf("port:%d\n" ,port);

  srv = setup_client(host_name, port);
  if(srv == -1)
    exit(1);

  /* Hand shake to SOS */
  memcpy(hs.name, user_name, NAME_LENGTH);
  hs.turn = user_turn;
  write(srv, &hs, sizeof(hs));

  read(srv, enemy_name, NAME_LENGTH);

  if(!strcmp(enemy_name, "Please Retry!")){
    close(srv);
    srv = setup_client(host_name, port);
    if(srv == -1)
      exit(1);

    /* Hand shake to SOS again */
    user_turn = change_turn(user_turn);
    hs.turn = user_turn;
    write(srv, &hs, sizeof(hs));

    i = read(srv, enemy_name, NAME_LENGTH);
    if(i == 0)
      exit(1);
  }

  printf("turn:%d\n" ,user_turn);

  enemy_name[NAME_LENGTH - 1] = '\0';
  printf("enemy_name:%s\n", enemy_name);

  if(user_turn == FIRST){
    player_name[0] = user_name;
    player_name[1] = enemy_name;
  }else{
    player_name[0] = enemy_name;
    player_name[1] = user_name;
  }

  while(1){
    read(srv, board, sizeof(board));
    read(srv, &turn, sizeof(turn));
    display(turn);

    if(turn == TURN){     /* �桼������ */

      if(movable_any(board, user_turn)){
	count = total_stone(board) - 4;
	think(board, user_turn, count, &pos[0], &pos[1]);
      }else{
	pos[0] = -1;
      }
      write(srv, pos, sizeof(pos));
    }else if(turn == WAIT){       /* Ũ���� */
      printf("Wait for enemy's thinking.\n");
    }else if(turn == STOP){
      break;
    }else{
      printf("Error\n");
      break;
    }
  }
  
  read(srv, pos, sizeof(pos));
  printf("\nG a m e O v e r\n");
  printf("%16s:%d\n", player_name[0], pos[0]);
  printf("%16s:%d\n", player_name[1], pos[1]);
  return 0;
}
