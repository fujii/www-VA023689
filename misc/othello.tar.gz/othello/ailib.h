#include <limits.h>

struct node{
  int board[BOARD_SIZE][BOARD_SIZE];
  int x, y;
  int count;
  int eval;
};

void alphabeta(struct node *node, int turn, int depth,
	       int alpha, int beta,
	       void (*func_eval_node)(struct node *node));

#define ALPHA_MIN INT_MIN
#define BETA_MAX  INT_MAX
