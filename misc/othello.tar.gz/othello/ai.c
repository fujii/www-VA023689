#include "othello.h"
#include "oth.h"
#include "ailib.h"

int count_stone(int board[BOARD_SIZE][BOARD_SIZE]){
  int result = 0;
  int x, y;

  for(y=0;y<BOARD_SIZE;y++)
    for(x=0;x<BOARD_SIZE;x++)
      result += board[x][y];

  return result;
}

int count_corner(int b[BOARD_SIZE][BOARD_SIZE]){
  return (b[0][0] + b[0][7] + b[7][0] + b[7][7]) * 10;
}

int count_movable(int b[BOARD_SIZE][BOARD_SIZE]){
  int rv = 0;
  int x, y;

  for(y=0;y<BOARD_SIZE;y++)
    for(x=0;x<BOARD_SIZE;x++)
      rv += movable_pos(b, 1, x, y);

  for(y=0;y<BOARD_SIZE;y++)
    for(x=0;x<BOARD_SIZE;x++)
      rv -= movable_pos(b, -1, x, y);

  return rv;
}


void eval_node(struct node *node){
  if(node->count < 55){
    node->eval = count_corner(node->board);
    node->eval += count_movable(node->board);
  }
  else
    node->eval = count_stone(node->board);
}

void think(int board[BOARD_SIZE][BOARD_SIZE],
	    int turn, int count,  int *x, int *y){
  struct node root;
  int depth = 6;

  if(depth >= 50)
    depth = 10;

  copy_board(board, root.board);
  root.count = count;
  alphabeta(&root, turn, depth, ALPHA_MIN, BETA_MAX, eval_node);

  /*printf("eval: %d\n", root.eval);*/

  *x = root.x;
  *y = root.y;
}

