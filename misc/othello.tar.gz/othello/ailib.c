#include "othello.h"
#include "oth.h"
#include "ailib.h"

void alphabeta(struct node *node, int turn, int depth,
	       int alpha, int beta ,
	       void (*func_eval_node)(struct node *node)){
  struct node child;
  int x, y;
  int enemy = change_turn(turn);

  if(depth == 0){
    func_eval_node(node);
    return;
  }

  if(!movable_any(node->board, turn)){
    if(movable_any(node->board, enemy)){
      alphabeta(node, enemy, depth, alpha, beta, func_eval_node);
      return;
    }else{
      func_eval_node(node);
      return;
    }
  }

  
  if(turn == 1)
    alpha = ALPHA_MIN;
  else
    beta = BETA_MAX;


  /*printf("Depth:%d  (%d,%d) a:%d b:%d\n",
    depth, node->x, node->y, alpha, beta);*/

  for(y=0;y<BOARD_SIZE;y++){
    for(x=0;x<BOARD_SIZE;x++){
      if(movable_pos(node->board, turn, x, y)){
	copy_board(node->board, child.board);
	move(child.board, turn, x, y);
	child.x = x;
	child.y = y;
	child.count = node->count + 1;


	/*printf("(%d,%d) d:%d a:%d b:%d\n", x, y, depth, alpha, beta);*/

	alphabeta(&child, enemy, depth - 1, alpha, beta, func_eval_node);


	if(turn == 1){ /* ��� */
	  if(alpha < child.eval){
	    alpha = child.eval;
	    node->eval = child.eval;
	    node->x = x;
	    node->y = y;
	  }
	}else{ /* ��� */ 
	  if(beta > child.eval){
	    beta = child.eval;
	    node->eval = child.eval;
	    node->x = x;
	    node->y = y;
	  }
	}
	
	if(alpha >= beta){
	  /*printf("Shot cut!\n");*/
	  return;
	}
      }
    }
  }
}
