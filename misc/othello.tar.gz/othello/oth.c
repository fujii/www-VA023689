#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "othello.h"
#include "oth.h"

int direct[][2] = { {0, 1}, {1, 1}, {1, 0}, {1, -1}, 
		    {0, -1}, {-1, -1}, {-1, 0}, {-1, 1}};

int DIRECT = 8; 

void move(int board[BOARD_SIZE][BOARD_SIZE],
	  int turn,
	  int x0, int y0){
  int dir;
  int x, y;
  int enemy = change_turn(turn);

  for(dir=0;dir<DIRECT;dir++){
    x = x0;
    y = y0;

    x += direct[dir][0];
    y += direct[dir][1];

    while(is_domain(x, y) &&
	  board[x][y] == enemy){
      x += direct[dir][0];
      y += direct[dir][1];

      if( ! is_domain(x, y))
	break;

      /* move */
      if(board[x][y] == turn){
	while(x != x0 || y != y0){
	  x -= direct[dir][0];
	  y -= direct[dir][1];
	  board[x][y] = turn;
	}
	break;
      }
    }
      
  }
}

int movable_any(int board[BOARD_SIZE][BOARD_SIZE],
		int turn){
  int  x0, y0;
  int  x, y;
  int enemy = change_turn(turn);
  int dir;

  for(y0=0;y0<BOARD_SIZE;y0++){
    for(x0=0;x0<BOARD_SIZE;x0++){

      if(is_empty(board, x0, y0)){
   
	for(dir=0;dir<DIRECT;dir++){
	  x = x0;
	  y = y0;

    
	  x += direct[dir][0];
	  y += direct[dir][1];

	  while(is_domain(x, y) &&
		board[x][y] == enemy){

	    x += direct[dir][0];
	    y += direct[dir][1];
	    if( ! is_domain(x, y))
	      break;

	    /* movable */
	    if(board[x][y] == turn){
	      return 1;
	    }
	  }

	}
      }
    }
  }
  return 0;
}

int movable_pos(int board[BOARD_SIZE][BOARD_SIZE],
		int turn, int x0, int y0){
  int  x, y;
  int enemy = change_turn(turn);
  int dir;

  if(is_empty(board, x0, y0)){
   
    for(dir=0;dir<DIRECT;dir++){
      x = x0;
      y = y0;
    
      x += direct[dir][0];
      y += direct[dir][1];

      while(is_domain(x, y) &&
	    board[x][y] == enemy){

	x += direct[dir][0];
	y += direct[dir][1];
	if( ! is_domain(x, y))
	  break;

	/* movable */
	if(board[x][y] == turn){
	  return 1;
	}
      }

    }
  }
  return 0;
}

void copy_board(int src[BOARD_SIZE][BOARD_SIZE],
		int to[BOARD_SIZE][BOARD_SIZE]){
  bcopy(src, to, sizeof(int) * BOARD_SIZE * BOARD_SIZE);
}



