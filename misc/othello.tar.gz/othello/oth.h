
/*int is_empty(int board[BOARD_SIZE][BOARD_SIZE], int x, int y);*/
#define is_empty(board, x, y) (!board[x][y])

/*int change_turn(int turn);*/
#define change_turn(turn) (-(turn))


/*#define is_domain(x, y) (!((x) >> 3) && !((y) >> 3))*/
#define is_domain(x, y) \
 ((x)>=0 && (x)<BOARD_SIZE && (y)>=0 && (y)<BOARD_SIZE)


void move(int board[BOARD_SIZE][BOARD_SIZE],
	  int turn,
	  int x0, int y0);

int movable(int board[BOARD_SIZE][BOARD_SIZE],
	     int turn,
	    int result[BOARD_SIZE][BOARD_SIZE]);

int movable_any(int board[BOARD_SIZE][BOARD_SIZE],
		int turn);

int movable_pos(int board[BOARD_SIZE][BOARD_SIZE],
		int turn, int x0, int y0);


/*void display(int board[BOARD_SIZE][BOARD_SIZE], int turn);*/

void copy_board(int src[BOARD_SIZE][BOARD_SIZE],
		int to[BOARD_SIZE][BOARD_SIZE]);

