/* setup_client.c utility program */

#include "othello.h"
#include "setup_client.h"
#include<stdio.h>
#include<string.h>


int setup_client(char *hostname,u_short port)
{
  struct hostent *servhost;
  struct sockaddr_in server;
  int s;
  
  if((servhost = gethostbyname(hostname)) == NULL){
    fprintf(stderr,"bad hostname!\n");
    return -1;
  }
  bzero((char*)&server,sizeof(server));
  server.sin_family = AF_INET;
  server.sin_port=htons(port);
  bcopy(servhost->h_addr,(char *)&server.sin_addr,servhost->h_length);
  if((s = socket(AF_INET,SOCK_STREAM,0))<0){
    fprintf(stderr,"socket allocation failed.\n");
    return -1;
  }
  fprintf(stderr,"created.\n");
  if(connect(s,&server,sizeof(server)) == -1){
    fprintf(stderr,"cannot bind.\n");
    return -1;
  }
  
  fprintf(stderr,"connected.\n");
  
  return s;
}
/* end of setup_client.c */
