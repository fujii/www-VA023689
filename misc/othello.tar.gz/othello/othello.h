/* othello.h: header file for Othello */

#ifndef __OTHELLO_H__
#define __OTHELLO_H__

/* Othello Game oriented */
#define BOARD_SIZE 8 
#define BOARD_DIM 2
#define PLAYER_NUM 2

/* Protocol oriented */

#define TURN 10
#define WAIT 11
#define STOP (-1)

#define FIRST 1
#define SECOND -1

#define NAME_LENGTH 16

#ifndef HANDSHAKE
#define HANDSHAKE
struct handshake{
       int  turn;
       char name[NAME_LENGTH];
};

#endif /* HANDSHAKE */

/* Other definition */

#define TRUE 1
#define FALSE 0
#define FAIL -1

#endif /* __OTHELLO_H__ */
/* end of othello.h */
