#include <stdio.h>
#include "othello.h"
#include "oth.h"

#define CROSS "��"
/*#define HLINE "--"*/
/*#define HLINE "  "*/
#define HLINE "��"
/*#define VLINE "  "*/
#define VLINE "��"

void display_with_number(int board[BOARD_SIZE][BOARD_SIZE], int turn){
  int x, y;
  int s, m = 0;

  /*printf("   0 1 2 3 4 5 6 7\n");*/
  printf(CROSS HLINE CROSS HLINE CROSS HLINE CROSS HLINE 
	 CROSS HLINE CROSS HLINE CROSS HLINE CROSS HLINE CROSS "\n");

  y = 0;
  while(1){
    x = 0;

    /*printf("%2d", y);*/
    printf(VLINE);

    while(1){
      s = board[x][y];

      if(s == 1)
	printf("��");
      else if(s == -1)
	printf("��");
      else 
	if(movable_pos(board, turn,  x, y))
	  printf("%2d", m++);
	else
	  printf("  ");

      printf(VLINE);

      x++;
      if(x >= BOARD_SIZE)
	break;

    }
    printf("\n");

    printf(CROSS HLINE CROSS HLINE CROSS HLINE CROSS HLINE 
	   CROSS HLINE CROSS HLINE CROSS HLINE CROSS HLINE CROSS "\n");

    y++;
    if(y >= BOARD_SIZE)
      break;
  }


}

void human(int board[BOARD_SIZE][BOARD_SIZE],
	   int turn, int count, int *x, int *y){

  /*struct node node;*/
  int n, xx, yy;

  /*copy_board(board, node.board);
    eval_node(&node);*/

  display_with_number(board, turn);

  do{

    printf("Input a number=\n");

    scanf("%d", &n);

    for(yy=0;yy<BOARD_SIZE;yy++){
      for(xx=0;xx<BOARD_SIZE;xx++){
	if(movable_pos(board, turn, xx, yy)){
	  n --;
	  if(n < 0){
	    *x = xx;
	    *y = yy;
	    printf("(x, y) = (%d, %d)\n", *x, *y);
	    return;
	  }
	}
      }
    }
  }while(1);
}
