#include <stdio.h>
#include <stdlib.h>

#include "othello.h"
#include "oth.h"


void human(int board[BOARD_SIZE][BOARD_SIZE],
	   int turn, int count, int *x, int *y);

void think2(int board[BOARD_SIZE][BOARD_SIZE],
	    int turn, int count,  int *x, int *y);
void think3(int board[BOARD_SIZE][BOARD_SIZE],
	    int turn, int count,  int *x, int *y);
void think4(int board[BOARD_SIZE][BOARD_SIZE],
	    int turn, int count,  int *x, int *y);



void result_game(int board[BOARD_SIZE][BOARD_SIZE]){
  int black = 0, white = 0;
  int x, y;
  
  for(y=0;y<BOARD_SIZE;y++){
    for(x=0;x<BOARD_SIZE;x++){
      if(board[x][y] == 1)
	black ++;
      else if(board[x][y] == -1)
	white ++;
    }
  }

  printf("G a m e O v e r !\n");
  printf("���: %d\n", black);
  printf("���: %d\n", white);
}

int main(int argc, char *argv[]){
  int board[BOARD_SIZE][BOARD_SIZE] = 
  { {0, 0, 0, 0, 0, 0, 0, 0}, 
    {0, 0, 0, 0, 0, 0, 0, 0}, 
    {0, 0, 0, 0, 0, 0, 0, 0}, 
    {0, 0, 0, -1, 1, 0, 0, 0}, 
    {0, 0, 0, 1, -1, 0, 0, 0}, 
    {0, 0, 0, 0, 0, 0, 0, 0}, 
    {0, 0, 0, 0, 0, 0, 0, 0}, 
    {0, 0, 0, 0, 0, 0, 0, 0}};
  int turn = 1;
  int count = 1;  
  int x, y;
  /*int mova[8][8];*/
  int ai[2];

  ai[0] = 3;
  ai[1] = 3;
  if(argc == 3){
    ai[0] = atoi(argv[1]);
    ai[1] = atoi(argv[2]);
  }
  if(argc == 2){
    ai[0] = atoi(argv[1]);
  }

  printf("%d, %d, %d\n", ai[0], ai[1], argc); 

  while(1){

    display(board, turn);
    printf("(%2d)", count);
    printf("turn = %d\n", turn);

    if( movable_any(board, turn)){

      switch(ai[(turn == 1 ? 0 : 1)]){
      case 1:
	human(board, turn, count, &x, &y);
	break;
      case 2:
	think2(board, turn, count, &x, &y);
	break;
      case 3:
	think3(board, turn, count, &x, &y);
	break;
      case 4:
	think4(board, turn, count, &x, &y);
	break;
      }

      printf("think:(%d,%d)\n", x, y);
      move(board, turn , x, y);
      count ++;
    }else if( !movable_any(board, change_turn(turn))){
      result_game(board);
      exit(0);
    }else{
      printf("Pass!\n");
    }

    turn = change_turn(turn);
  }
  exit(0);
}
