#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv[])
{
  int c;
  unsigned long n = 10;

  if (argc > 1)
    n = strtol (argv[1], 0, 0);

  while (n-- > 0 && (c = getchar()) != EOF)
    if (putchar (c) == EOF)
      return EXIT_FAILURE;
  
  return 0;
}
