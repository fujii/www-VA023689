#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void print_hex (int x)
{
  if (x < 10)
    putchar ('0' + x);
  else
    putchar ('a' + x - 10);
}


int main (int argc, char *argv[])
{
  int c;
  int w=0, width = 0;

  while (1) {
    int c = getopt (argc, argv, "w:");
    if (c == -1)
      break;
    switch (c) {
    case 'w':
      width = strtol (optarg, 0, 0);
      break;
    }
  }

  while ((c = getchar()) != EOF) {

    print_hex (c >> 4);
    print_hex (c & 0x0f);

    if (width) {
      w ++;
      if (w >= width) {
	w = 0;
	putchar ('\n');
      } else {
	putchar (' ');
      }
    } else {
      putchar (' ');
    }
  }  
  return 0;
}
