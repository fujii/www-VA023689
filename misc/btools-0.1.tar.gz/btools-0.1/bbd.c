#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void print_bin (int x)
{
  int i;
  for (i=0x80; i; i >>= 1)
    putchar (x & i ? '1' : '0');
}

int main (int argc, char *argv[])
{
  int c;
  int w=0, width = 0;

  while (1) {
    int c = getopt (argc, argv, "w:");
    if (c == -1)
      break;
    switch (c) {
    case 'w':
      width = strtol (optarg, 0, 0);
      break;
    }
  }

  while ((c = getchar()) != EOF) {

    print_bin (c);

    if (width) {
      w ++;
      if (w >= width) {
	w = 0;
	putchar ('\n');
      } else {
	putchar (' ');
      }
    } else {
      putchar (' ');
    }
  }  
  return 0;
}
