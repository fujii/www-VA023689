open Printf
open Fujii

let pi = 4.0 *. atan 1.0
let g = 9.8

(*
let regularize angle =
  let c = pi *. 2. in
  if angle < 0. then angle +. c
  else if angle >= c then angle -. c
  else angle
*)

let regularize angle =
  if angle < -.pi then angle +. 2. *. pi
  else if angle >= pi then angle -. 2. *.pi
  else angle

class pole
  m_cart				(* weight of cart *)
  m_pole				(* weight of pole *)
  l_pole				(* length of pole *)
  tau
  = object (self)
    val mutable theta   = 0.
    val mutable theta'  = 0.
    val mutable theta'' = 0.
    val mutable h   = 0.
    val mutable h'  = 0.
    val mutable h'' = 0.

    method theta  () = theta
    method theta' () = theta'
    method h  () = h
    method h' () = h'

    method set_theta  v = theta  <- v
    method set_theta' v = theta' <- v
    method set_h  v = h  <- v
    method set_h' v = h' <- v

    method step f =
      let calc_theta'' f =
	theta'' <-
	(g *. sin theta
	 +. cos theta
	 *. (-.f -. m_pole*.l_pole*.theta'*.theta'*.sin theta)
	 /. (m_cart +. m_pole))
	/. l_pole *. (4./.3. -. m_pole*.cos theta*.cos theta /. (m_cart+.m_pole)) in
      let calc_h'' f =
	h'' <-
	(f +. m_pole*.l_pole*.(theta''*.theta''*.sin theta -. theta''*.cos theta))
	/. (m_cart +. m_pole)
      in
	calc_theta'' f;
	calc_h'' f;
	theta <- regularize (theta +. theta'*.tau);
	theta' <- theta' +. theta''*.tau;
	h <- h +. h'*.tau;
	h' <- h' +. h'' *.tau
  end

let run_1 () =
  let pole = new pole 1. 0.1 0.5 0.01 in
  let iter () =
    pole#step (20. *. sin (pole#theta ()));
    printf "%f %f %f %f\n" (pole#theta ()) (pole#theta' ()) (pole#h ()) (pole#h' ()) in
    pole#set_theta 0.1;
    iterator 200 iter ()

let _ = run_1 ()
