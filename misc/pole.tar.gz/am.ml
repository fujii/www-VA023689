(* ���� *)
let mul_sum xs ys =
  let sum = ref 0. in
    for i=0 to Array.length xs - 1 do
      sum := !sum +. xs.(i) *. ys.(i)
    done;
    !sum

let f u =
  if u >= 0.
  then 1.
  else -1.

class am n_neuron_cue n_neuron_target alpha beta memorize_method =
  let valid_cue_pat pat =
    Array.length pat = n_neuron_cue in
  let valid_target_pat pat =
    Array.length pat = n_neuron_target in
object (self)
  (*
    val wss =				(* weights *)
    Array.init n_neuron_target (fun _ -> (Array.make n_neuron_cue 0.))
  *)
  val wss =				(* weights *)
    Array.init n_neuron_target (fun _ -> (Array.make n_neuron_cue (Random.float 2. -. 1.)))

  val xs = Array.make n_neuron_target 0. (* outputs *)

  method wss () = wss
  method xs () = xs

  method reinit	() =
    Array.iteri (fun i ws -> Array.iteri (fun j _ -> wss.(i).(j) <- 0.) ws) wss

  method reinit_random () =
    let random_float () = Random.float 2. -. 1. in
      Array.iteri (fun i ws -> Array.iteri (fun j _ -> wss.(i).(j) <- random_float ()) ws) wss

  method recall cue =
    assert (valid_cue_pat cue);
    Array.iteri (fun i ws -> xs.(i) <- f (mul_sum ws cue)) wss

  method overlap pat =
    mul_sum xs pat /. float_of_int n_neuron_target

  method memorize_1 cue target =
    assert (valid_cue_pat cue);
    assert (valid_target_pat target);
    Array.iteri
      (fun i t -> Array.iteri
	 (fun j c -> wss.(i).(j) <-
	    wss.(i).(j) +. c *. t *. alpha -. wss.(i).(j) *. beta)
	 cue) target

  method memorize_2 cue target =
    assert (valid_cue_pat cue);
    assert (valid_target_pat target);
    self#recall cue;
    Array.iteri
      (fun i t -> 
	 if t <> xs.(i) then
	   Array.iteri
	     (fun j c -> wss.(i).(j) <- wss.(i).(j) +. c *. t *. alpha -. wss.(i).(j) *. beta)
	     cue) target

  method memorize_3 cue target =
    assert (valid_cue_pat cue);
    assert (valid_target_pat target);
    Array.iteri
      (fun i t -> 
	 let ms = mul_sum wss.(i) cue -. t in
	   if t *. ms < 0. then
	     let d_w = -. ms /. float n_neuron_cue *. alpha in
	       Array.iteri
		 (fun j c -> wss.(i).(j) <- wss.(i).(j) +. c *. d_w -. wss.(i).(j) *. beta)
		 cue) target

  method memorize_4 cue target =
    assert (valid_cue_pat cue);
    assert (valid_target_pat target);
    Array.iteri
      (fun i t -> 
	 let ms = mul_sum wss.(i) cue in
	   if t *. ms /. float n_neuron_target < 1.0 then
	     Array.iteri
	       (fun j c -> wss.(i).(j) <- wss.(i).(j) +. c *. t *.alpha -. wss.(i).(j) *. beta)
	       cue) target

  method memorize =
    match memorize_method with
	1 -> self#memorize_1
      | 2 -> self#memorize_2
      | 3 -> self#memorize_3
      | 4 -> self#memorize_4
      | _ -> failwith "memorize"
end

(*  *)
