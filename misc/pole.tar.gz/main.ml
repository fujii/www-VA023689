open Printf
open Fujii

let pi = 4.0 *. atan 1.0

let n_neuron_a = 100
let n_neuron_r = 100

let n_a = 2
let n_r = 5

let m_cart = 1.0
let m_pole = 0.1
let l_pole = 0.5
let tau = 0.1

let make_random_pattern n =
  Array.init n (fun _ -> if Random.bool () then 1. else -1.)

let a_pats = Array.init n_a (fun _ -> make_random_pattern n_neuron_a)
let r_pats = Array.init n_r (fun _ -> make_random_pattern n_neuron_r)

let n_neuron_s_theta = 50
let n_neuron_s_theta' = 50
let n_neuron_s = n_neuron_s_theta + n_neuron_s_theta'
let s_pat = Array.make n_neuron_s 0.

let float_to_pat f low high pat =
  let len = Array.length pat in
  let int = int_of_float ((f -. low) *. float len /. (high -. low)) in
    for i=0 to len-1 do
      pat.(i) <- if i < int then 1. else -1.
    done

let make_s_pat =
  let theta_pat = Array.make n_neuron_s_theta 0. in
  let theta'_pat = Array.make n_neuron_s_theta' 0. in
    fun pole pat ->
      float_to_pat (pole#theta ()) (-.pi/.2.) (pi/.2.) theta_pat;
      float_to_pat (pole#theta' ()) (-.pi/.2.) (pi/.2.) theta'_pat;
      let p = ref 0 in
	Array.iter
	  (fun x ->
	     pat.(!p) <- x;
	     incr p)
	  theta_pat;
	Array.iter
	  (fun x ->
	     pat.(!p) <- x;
	     incr p)
	  theta'_pat

let a_to_f a = match a with
    0 -> -10.
  | 1 -> 10.
  | _ -> failwith "a_to_f"

(*
let one_exam sar pre_pole pole print_pole_p print_a_p =
  let rec iter n r =
    let end_p =
      pole#theta () > pi/.2. || pole#theta () < -.pi/.2.
      || n >= 1000 in
      if end_p
      then (r, n)
      else begin
	if print_pole_p then printf "% f % f" (pole#theta ()) (pole#theta' ());
	pre_pole#dup pole;
	make_s_pat pole s_pat;
	(let a = sar#think_a r (Some s_pat) in
	   if print_a_p then printf " %+4.1fN %s\n" (a_to_f a) (sar#why_a ());
	   pole#step (a_to_f a);
	);
	iter (n+1)
	  (Some (if abs_float (pre_pole#theta ()) > abs_float (pole#theta ()) then 1 else 0));
      end in
    pole#set_init ();
    match iter 0 None with
	(r, n) ->
	  ignore (sar#think_a r None);
	  n
*)

let one_exam sar pre_pole pole print_pole_p print_a_p =
  let n_to_r n =
    let sec = int_of_float (float n *. tau *. 2.) in
      if sec >= n_r
      then n_r -1
      else sec in
  let rec iter n =
    let end_p =
      pole#theta () > pi/.2. || pole#theta () < -.pi/.2.
      || n >= 1000 in
      if end_p
      then n
      else begin
	if print_pole_p then printf "% f % f" (pole#theta ()) (pole#theta' ());
	pre_pole#dup pole;
	make_s_pat pole s_pat;
	(let a = sar#think_a None (Some s_pat) in
	   if print_a_p then printf " %+4.1fN %s\n" (a_to_f a) (sar#why_a ());
	   pole#step (a_to_f a);
	);
	iter (n+1);
      end in
    pole#set_init ();
    let n = iter 0 in
      ignore (sar#think_a (Some (n_to_r n)) None);
      printf "%d %d\n" n (n_to_r n);
      n

let exam_once pre_pole pole sar =
  ignore (one_exam sar pre_pole pole true true)

let exam_n_times pre_pole pole sar =
  let iter () =
    (* printf "%d\n" (one_exam sar pre_pole pole false false); *)
    (* ignore (one_exam sar pre_pole pole false false); *)
    (* ignore (one_exam sar pre_pole pole true true); *)
    ignore (one_exam sar pre_pole pole true true);
    flush stdout in
    iterator 200 iter ()

let exam_after_n pre_pole pole sar =
  let iter () =
    ignore (one_exam sar pre_pole pole false false) in
    iterator 100 iter ();
    exam_once pre_pole pole sar

class randomer =
object 
  val mutable a = -1
  val mutable why_a = "rnd"

  method a () = a
  method why_a () = why_a

  method think_a (r : int option) (s : float array option) =
    a <- Random.int n_a;
    a
end

let _ = 
  let pre_pole = (new Pole.pole m_cart m_pole l_pole tau) in
  let pole = (new Pole.pole m_cart m_pole l_pole tau) in
  let sar = 
    match int_of_string Sys.argv.(1) with
	1 -> new Sar.sar n_neuron_s a_pats r_pats 0.5 0.5 0.05 0.05
      | 2 -> new randomer
      | n -> failwith "not defined" in
    match int_of_string Sys.argv.(2) with
	1 -> exam_once pre_pole pole sar
      | 2 -> exam_n_times pre_pole pole sar
      | 3 -> exam_after_n pre_pole pole sar
      | n -> printf "not defined: %d\n" n
