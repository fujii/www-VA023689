open Printf
open Fujii

let pi = 4.0 *. atan 1.0

let n_neuron_a = 100
let n_neuron_r = 100

let n_a = 2
let n_r = 2

let make_random_pattern n =
  Array.init n (fun _ -> if Random.bool () then 1. else -1.)

let a_pats = Array.init n_a (fun _ -> make_random_pattern n_neuron_a)
let r_pats = Array.init n_r (fun _ -> make_random_pattern n_neuron_r)

let n_neuron_s_theta = 50
let n_neuron_s_theta' = 50
let n_neuron_s = n_neuron_s_theta + n_neuron_s_theta'
let s_pat = Array.make n_neuron_s 0.

let float_to_pat f low high pat =
  let len = Array.length pat in
  let int = int_of_float ((f -. low) *. float len /. (high -. low)) in
    for i=0 to len-1 do
      pat.(i) <- if i < int then 1. else -1.
    done

let make_s_pat =
  let theta_pat = Array.make n_neuron_s_theta 0. in
  let theta'_pat = Array.make n_neuron_s_theta' 0. in
    fun pole pat ->
      float_to_pat (pole#theta ()) (-.pi/.2.) (pi/.2.) theta_pat;
      float_to_pat (pole#theta' ()) (-.pi/.2.) (pi/.2.) theta'_pat;
      let p = ref 0 in
	Array.iter
	  (fun x ->
	     pat.(!p) <- x;
	     incr p)
	  theta_pat;
	Array.iter
	  (fun x ->
	     pat.(!p) <- x;
	     incr p)
	  theta'_pat

let a_to_f a = match a with
    0 -> -20.
  | 1 -> 20.
  | _ -> failwith "a_to_f"

let one_exam sar pole print_pole =
  let rec iter n r pre_theta =
    let end_p =
      pole#theta () > pi/.2. || pole#theta () < -.pi/.2.
      || n >= 1000 in
      if end_p
      then (r, n)
      else begin
	print_pole pole;
	make_s_pat pole s_pat;
	(let a = sar#think_a r (Some s_pat) in
	   pole#step (a_to_f a);
	);
	iter (n+1)
	  (Some (if abs_float pre_theta > abs_float (pole#theta ()) then 1 else 0)) (pole#theta ());
      end in
    pole#set_init ();
    match iter 0 None (pole#theta ()) with
	(r, n) ->
	  ignore (sar#think_a r None);
	  n

let exam () = 
  let sar = new Sar.sar n_neuron_s a_pats r_pats 2.0 0.5 0.01 0.001 in
  let pole = (new Pole.pole 1.0 0.1 0.5 0.01) in
  let print_pole pole = printf "%f %f\n" (pole#theta ()) (pole#theta' ()) in
    sar#set_print_a_str (fun a str -> printf "%d %s " a str);
    one_exam sar pole print_pole

let exam_2 () = 
  let sar = new Sar.sar n_neuron_s a_pats r_pats 1.0 0.1 0.01 0.001 in
  let pole = (new Pole.pole 1.0 0.1 0.5 0.01) in
  let iter () =
    printf "%d\n" (one_exam sar pole ignore);
    flush stdout in
    iterator 100 iter ()

(* let _ = exam () *)
