(*
#load "fujii.cmo";;
#load "am.cmo";;
*)

let _ = Random.self_init ()

let make_random_pat n =
  Array.init n (fun _ -> if Random.bool () then 1. else -1.)

(*
let calc_overlaps overlaps am patterns =
  assert ((Array.length overlaps) = (Array.length patterns));
  Array.iteri (fun i p -> overlaps.(i) <- am#overlap p) patterns

let array_max a =
  let max = ref a.(0) in
  let idx = ref 0 in
    for i=1 to Array.length a - 1 do
      if !max < a.(i)
      then (
	max := a.(i);
	idx := i
      )
    done;
    !idx

let state_action am overlaps state_idx =
  am#cue state_patterns.(state_idx);
  calc_overlaps overlaps am action_patterns;
  let idx = array_max overlaps in
    if overlaps.(idx) > 0.3 then
      Some idx
    else
      None

let state_reward am overlaps state_idx =
  am#cue state_patterns.(state_idx);
  calc_overlaps overlaps am reward_patterns;
  let idx = array_max overlaps in
    if overlaps.(idx) > 0.3 then
      Some idx
    else
      None
*)

let meth = 4

class sar n_neuron_s a_pats r_pats m_alpha m_beta l_alpha l_beta =
object (self)
  val n_a = Array.length a_pats
  val n_r = Array.length r_pats
  val m_sa = new Am.am n_neuron_s (Array.length a_pats.(0)) m_alpha m_beta meth
  val m_sr = new Am.am n_neuron_s (Array.length r_pats.(0)) m_alpha m_beta meth
  val l_sa = new Am.am n_neuron_s (Array.length a_pats.(0)) l_alpha l_beta meth
  val l_sr = new Am.am n_neuron_s (Array.length r_pats.(0)) l_alpha l_beta meth
  val mutable pre_s = None
  val pre_s_pat = Array.make n_neuron_s 0.

  val mutable print_a_str = fun a str -> ()

  method set_print_a_str fn = print_a_str <- fn

  method think_a r s =
    let recall am cue pats =
      am#recall cue;
      let max_i = ref 0 in
      let max = ref (am#overlap pats.(0)) in
	for i=1 to Array.length pats - 1 do
	  if !max < am#overlap pats.(i) then (
	    max_i := i;
	    max := am#overlap pats.(i)
	  )
	done;
	if !max > 0.3
	then Some !max_i
	else None in

    (* random action. return the index of action *)
    let rand_a () = Random.int n_a in

    (* like rand_a except ex_a won't be selected. *)
    let rand_a_ex ex_a =
      let a = Random.int (n_a-1) in
	if a = ex_a
	then n_a-1
	else a in

    let determine ma mr la lr =
      match (ma, mr, la, lr) with
	  (Some ma, Some mr, Some la, Some lr) ->
	    if ma = la && mr = lr then
	      if Random.int 5 = 0
	      then (rand_a_ex ma, "explore")
	      else (la, "mtm=ltm")
	    else if mr < lr
	    then (la, "ltm>mtm")
	    else (ma, "mtm>ltm")
	| (Some ma, Some mr, _, _) -> (ma, "mtm")
	| (_, _, Some la, Some lr) -> (la, "ltm")
	| (_, _, _, _) -> (rand_a (), "rnd") in
    let propagate_reward am s_pre s_cur =
      am#recall s_cur;
      am#memorize s_pre (am#xs ()) in

      (* s��r �ؤε��� *)
      (match pre_s, s, r with
	 | Some pre_s_pat, _, Some r ->
	     m_sr#memorize pre_s_pat r_pats.(r);
	     l_sr#memorize pre_s_pat r_pats.(r);
	 | Some pre_s_pat, Some s_pat, None ->
	     propagate_reward m_sr pre_s_pat s_pat;
	     propagate_reward l_sr pre_s_pat s_pat;
	 | _, _, _ -> ());
      (* s �� pre_s ����¸ *)
      (match s with
	   None -> pre_s <- None
	 | Some s_pat ->
	     pre_s <- Some pre_s_pat;
	     Array.iteri (fun i s -> pre_s_pat.(i) <- s_pat.(i)) s_pat);
      (* s ����۵�����ư�η��� *)
      match s with
	  None -> 0
	| Some s_pat ->
	    match (determine (recall m_sa s_pat a_pats) (recall m_sr s_pat r_pats)
		     (recall l_sa s_pat a_pats) (recall l_sr s_pat r_pats)) with
		(a, str) -> 
		  print_a_str a str;
		  m_sa#memorize s_pat a_pats.(a);
		  l_sa#memorize s_pat a_pats.(a);
		  a
end

(* test *)
open Fujii
open Printf

(* state��1�� *)
let test () =
  let n_neuron_s = 50 in
  let n_a = 5 in
  let a_pats = Array.init n_a (fun _ -> make_random_pat 51) in
  let r_pats = Array.init n_a (fun _ -> make_random_pat 52) in
  let s_pat = make_random_pat n_neuron_s in
  let m_alpha = 0.5 in
  let m_beta = m_alpha in
  let l_alpha = 0.05 in
  let l_beta = l_alpha in
  let sar = new sar n_neuron_s a_pats r_pats m_alpha m_beta l_alpha l_beta in
  let iter r =
    let a = sar#think_a r (Some s_pat) in
    Some a in
    sar#set_print_a_str (Printf.printf "%d %s \n");
    iterator 200 iter None
      

(* let _ = test () *)
