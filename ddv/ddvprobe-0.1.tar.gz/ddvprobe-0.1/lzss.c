#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <iconv.h>

#define NELEMS(x) ((sizeof (x))/(sizeof ((x)[0])))

char *utf_to_euc (unsigned char u1, unsigned char u2)
{
  iconv_t cd = iconv_open ("EUC-JP", "UTF-16LE");
  char from[2] = {u1, u2};
  static char to[6];
  char *inbuf = from, *outbuff = to;
  size_t inl=2, outl=NELEMS(to);
  int i;

  for (i=0; i<NELEMS (to); i++)
    to[i] = 0;

  iconv (cd, &inbuf, &inl, &outbuff, &outl);

  iconv_close (cd);
  return to;
}


unsigned char *input;
int input_size;
int pos_idx = 0;
int pos_bit = 7;

int out_idx = 0;

int get_bit (void)
{
  int f = input[pos_idx] & (1 << pos_bit);
  pos_bit --;
  if (pos_bit < 0) {
    pos_bit = 7;
    pos_idx ++;
  }
  return !!f;
}

int get_oct (void)
{
  int a7 = get_bit();
  int a6 = get_bit();
  int a5 = get_bit();
  int a4 = get_bit();
  int a3 = get_bit();
  int a2 = get_bit();
  int a1 = get_bit();
  int a0 = get_bit();
  return a7 << 7 | a6 << 6 | a5 << 5 | a4 << 4 | a3 << 3 | a2 << 2 | a1 << 1 | a0;
}

int get_5 (void)
{
  int a4 = get_bit();
  int a3 = get_bit();
  int a2 = get_bit();
  int a1 = get_bit();
  int a0 = get_bit();
  return a4 << 4 | a3 << 3 | a2 << 2 | a1 << 1 | a0;
}

int main (int argc, char *argv[])
{
  int flag;
  int ch, pos, len;
  unsigned char pre_char = 0;
  
  assert (input = malloc (4700));

  input_size = fread (input, 1, 4700, stdin);

  while (pos_idx < input_size) {
    flag = get_bit ();
    if (flag) {
      ch = get_oct ();
      if (out_idx & 1)
	printf ("%d: %02x (%s)\n", flag, ch, utf_to_euc (pre_char, ch));
      else
	printf ("%d: %02x\n", flag, ch);
      out_idx ++;
      pre_char = ch;
    } else {
      pos = get_oct ();
      len = get_5 () + 2;
      printf ("%d: pos=%d len=%d\n", flag, pos, len);

      pre_char = 0;
      out_idx += len;
    }
  }

  printf ("out_idx: %d\n", out_idx);

  return 0;
}
