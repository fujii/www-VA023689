#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "oct.h"

#define NELEMS(x) ((sizeof (x))/(sizeof ((x)[0])))

int main (int argc, char *argv[])
{
  unsigned char header[0x50];
  FILE *fp;
  unsigned long num16, num1a, num1e, num40, n_chunk;

  
  assert (fp = fopen (argv[1], "rb"));

  fread (header, sizeof header, 1, fp);
  num16 = oct_cat4_le (&header[0x16]);
  num1a = oct_cat4_le (&header[0x1a]);
  num1e = oct_cat4_le (&header[0x1e]);
  num40 = oct_cat4_le (&header[0x40]);

  printf ("num16: %ld 0x%lx\n", num16, num16);
  printf ("num1a: %ld 0x%lx\n", num1a, num1a);
  printf ("num1e: %ld 0x%lx\n", num1e, num1e);
  printf ("num40: %ld 0x%lx\n", num40, num40);

  n_chunk = (num1a - 0x50) / 4;
  printf ("n_chunk: %ld 0x%lx\n", n_chunk, n_chunk);

  printf ("num40/n_chunk: %f\n", (double) num40 / n_chunk);

  return 0;
}
