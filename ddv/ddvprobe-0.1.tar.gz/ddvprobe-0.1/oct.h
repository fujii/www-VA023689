#define oct_cat4(a, b, c, d) ((a << 24) | (b << 16) | (c << 8) | d)
#define oct_cat2(a, b) ((a << 8) | b)

#define oct_cat4_le(a) oct_cat4 ((a)[3], (a)[2], (a)[1], (a)[0])
