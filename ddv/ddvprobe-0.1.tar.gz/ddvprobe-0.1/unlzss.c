#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <iconv.h>

#define NELEMS(x) ((sizeof (x))/(sizeof ((x)[0])))

unsigned char *input;
int input_size;
int pos_idx = 0;
int pos_bit = 7;

int get_bit (void)
{
  int f = input[pos_idx] & (1 << pos_bit);
  pos_bit --;
  if (pos_bit < 0) {
    pos_bit = 7;
    pos_idx ++;
  }
  return !!f;
}

int get_oct (void)
{
  int a7 = get_bit();
  int a6 = get_bit();
  int a5 = get_bit();
  int a4 = get_bit();
  int a3 = get_bit();
  int a2 = get_bit();
  int a1 = get_bit();
  int a0 = get_bit();
  return a7 << 7 | a6 << 6 | a5 << 5 | a4 << 4 | a3 << 3 | a2 << 2 | a1 << 1 | a0;
}

int get_5 (void)
{
  int a4 = get_bit();
  int a3 = get_bit();
  int a2 = get_bit();
  int a1 = get_bit();
  int a0 = get_bit();
  return a4 << 4 | a3 << 3 | a2 << 2 | a1 << 1 | a0;
}

int win_pos = 0;
unsigned char window[256];

void put (unsigned char c)
{
  win_pos ++;
  win_pos %= NELEMS (window);
  window[win_pos] = c;
  putchar (c);
}

void copy (int pos, int lenght)
{
  int i;
  for (i=0; i<lenght; i++)
    put (window[(pos+i) % NELEMS(window)]);
}

int main (int argc, char *argv[])
{
  //int i;
  int flag;
  int ch, pos, len;
  
  assert (input = malloc (4700));

  input_size = fread (input, 1, 4700, stdin);

  while (pos_idx < input_size) {
    flag = get_bit ();
    if (flag) {
      ch = get_oct ();
      put (ch);
    } else {
      pos = get_oct ();
      len = get_5 () + 2;
      copy (pos, len);
    }
  }

  return 0;
}
