#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "oct.h"

#define NELEMS(x) ((sizeof (x))/(sizeof ((x)[0])))

int main (int argc, char *argv[])
{
  int i, j;
  unsigned char header[0x50];
  unsigned char offset[4];
  FILE *fp, *fp_chunk;
  unsigned long num1a, num1e, n_chunk;
  unsigned long *offsets;
  char chunk_filename[256];

  assert (argc == 2);  
  assert (fp = fopen (argv[1], "rb"));

  fread (header, sizeof header, 1, fp);
  num1a = oct_cat4_le (&header[0x1a]);
  num1e = oct_cat4_le (&header[0x1e]);

  n_chunk = (num1a - 0x50) / 4;

  assert (offsets = malloc ((n_chunk+1) * 4));

  for (i=0; i<n_chunk; i++) {
    fread (offset, sizeof offset, 1, fp);
    offsets[i] = oct_cat4_le (&offset[0]);
    //printf ("offsets[%d]: %ld %4lx\n", i, offsets[i], offsets[i]);
  }
  offsets[n_chunk] = num1e;

  j=0;
  for (i=0; i<n_chunk; i++) {
    sprintf (chunk_filename, "%s%05x", "a", i);
    assert (fp_chunk = fopen (chunk_filename, "wb"));
    for (; j<offsets[i+1]; j++)
      fputc (fgetc (fp), fp_chunk);
    fclose (fp_chunk);
  }

  return 0;
}
